﻿using System.Windows;
using AutoMapper;
using CompanyAccount.Mapper;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App
    {
        public static IMapper Mapper { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new ProductMapperProfile());
                cfg.AddProfile(new EmployeeMapperProfile());
                cfg.AddProfile(new CustomerMapperProfile());
                cfg.AddProfile(new SupplierMapperProfile());
                cfg.AddProfile(new MaterialMapperProfile());
            });
            Mapper = config.CreateMapper();
        }
    }
}
