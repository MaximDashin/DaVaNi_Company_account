﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Interaction logic for ThreadTablePage.xaml
    /// </summary>
    public partial class ThreadTablePage : Page
    {
        public ThreadTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new((DataContext as ThreadTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as ThreadTableVM).Delete();
        }

    }
}
