﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Interaction logic for AddEditMaterialWindow_new.xaml
    /// </summary>
    public partial class AddEditMaterialWindow_new : Window
    {
        private int _materialId;

        public AddEditMaterialWindow_new(int materialId = 0)
        {
            InitializeComponent();
            if (materialId == 0)
            {
                btnAccept.Content = "Добавить";
                Title = "Добавить материал";
            }
            else
            {
                _materialId = materialId;
                btnAccept.Content = "Изменить";
                Title = "Изменить материал";
            }
            DataContext = new AddEditMaterialVM_new(materialId);
        }

        public new AddEditMaterialVM_new DataContext
        {
            get { return base.DataContext as AddEditMaterialVM_new; }
            set { base.DataContext = value; }
        }

        #region Buttons, event: OnClick
        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnAccept_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_materialId);
        }
        #endregion

    }
}
