﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Interaction logic for FurTablePage.xaml
    /// </summary>
    public partial class FurTablePage : Page
    {
        public FurTablePage()
        {
            InitializeComponent();
        }
        #region buttons
        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new((DataContext as FurTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as FurTableVM).Delete();
        }
        #endregion

    }
}
