﻿using System.Windows;
using System.Windows.Input;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Логика взаимодействия для AddEditMaterialsWindow.xaml
    /// </summary>
    public partial class AddEditMaterialsWindow : Window
    {
        private int _materialId;

        public AddEditMaterialsWindow(int materialId = 0)
        {
            InitializeComponent();
            if (materialId == 0)
            {
                btnAccept.Content = "Добавить";
                Title = "Добавить материал";
            }
            else
            {
                _materialId = materialId;
                btnAccept.Content = "Изменить";
                Title = "Изменить материал";
            }
        }

        #region Buttons, event: OnClick
        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnAccept_OnClick(object sender, RoutedEventArgs e)
        {

        }
        #endregion

        #region Validation
        private void TextBox_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1))
            {
                e.Handled = true;
            }
        }
        #endregion
    }
}
