﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Логика взаимодействия для MaterialsPage.xaml
    /// </summary>
    public partial class MaterialsPage : Page
    {
        public MaterialsPage()
        {
            InitializeComponent();
        }

        #region Control buttons event: OnClick
        private void Material_Textile_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/TextileTablePage.xaml", UriKind.Relative));
        }

        private void Material_Leather_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/LeatherTablePage.xaml", UriKind.Relative));
        }

        private void Material_Fur_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/FurTablePage.xaml", UriKind.Relative));
        }

        private void Material_Lining_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/LiningTablePage.xaml", UriKind.Relative));
        }

        private void Material_Latex_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/LatexTablePage.xaml", UriKind.Relative));
        }

        private void Material_FoamRubber_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/FoamRubberPage.xaml", UriKind.Relative));
        }

        private void Material_Sintepon_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/SinteponTablePage.xaml", UriKind.Relative));
        }

        private void Material_Visor_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/VisorTablePage.xaml", UriKind.Relative));
        }

        private void Material_Thread_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Materials/ThreadTablePage.xaml", UriKind.Relative));
        }
        #endregion



    }
}
