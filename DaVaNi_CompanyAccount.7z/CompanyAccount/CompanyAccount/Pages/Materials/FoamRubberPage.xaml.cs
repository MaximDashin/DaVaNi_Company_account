﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Materials
{
    /// <summary>
    /// Interaction logic for FoamRubberPage.xaml
    /// </summary>
    public partial class FoamRubberPage : Page
    {
        public FoamRubberPage()
        {
            InitializeComponent();
        }
        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditMaterialWindow_new window = new AddEditMaterialWindow_new((DataContext as FoamRubberTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as FoamRubberTableVM).Delete();
        }

    }
}
