﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.Pages.Customers.Orders;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Customers
{
    /// <summary>
    /// Interaction logic for CustomersTablePage.xaml
    /// </summary>
    public partial class CustomersTablePage : Page
    {
        public CustomersTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditCustomerContactsWindow window = new AddEditCustomerContactsWindow();
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as CustomerTableVM).Delete();
        }

        private void Contacts_OnClick(object sender, RoutedEventArgs e)
        {
            CustomerInformationWindow window =
                new CustomerInformationWindow((DataContext as CustomerTableVM).SelectedItem.Id)
                { Owner = Window.GetWindow(this) };
            window.Show();
        }

        private void Orders_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrdersTablePage((DataContext as CustomerTableVM).SelectedItem.Id));
        }
    }
}
