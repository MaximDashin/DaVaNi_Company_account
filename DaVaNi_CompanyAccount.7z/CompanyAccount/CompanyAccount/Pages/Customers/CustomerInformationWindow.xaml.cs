﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Customers
{
    /// <summary>
    /// Interaction logic for CustomerInformationWindow.xaml
    /// </summary>
    public partial class CustomerInformationWindow : Window
    {
        public new AddEditCustomerContactsVM DataContext
        {
            get { return base.DataContext as AddEditCustomerContactsVM; }
            set { base.DataContext = value; }
        }

        public CustomerInformationWindow(int id)
        {
            InitializeComponent();
            DataContext = new AddEditCustomerContactsVM(id);
        }

        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditCustomerContactsWindow window = new AddEditCustomerContactsWindow(DataContext.Id);
            Close();
            window.ShowDialog();
        }
    }
}
