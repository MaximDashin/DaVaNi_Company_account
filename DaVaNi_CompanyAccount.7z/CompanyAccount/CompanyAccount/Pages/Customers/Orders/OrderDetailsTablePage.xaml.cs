﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Customers.Orders
{
    /// <summary>
    /// Interaction logic for OrderDetailsTablePage.xaml
    /// </summary>
    public partial class OrderDetailsTablePage : Page
    {
        private int _orderId;
        private int _customerId;

        public new OrderDetailsTableVM DataContext
        {
            get { return base.DataContext as OrderDetailsTableVM; }
            set { base.DataContext = value; }
        }

        //todo: изменить представление даты
        public OrderDetailsTablePage(int orderId = 0, int customerId = 0)
        {
            InitializeComponent();
            if (orderId == 0)
            {
                Title = "Добавить заказ";
                txtbTableName.Text = "Добавить заказ";
            }
            else
            {
                _orderId = orderId;
                _customerId = customerId;

                Title = "Заказ №" + DataContext.GetOrderNumber(orderId);
                txtbTableName.Text = "Заказ №" + DataContext.GetOrderNumber(orderId);
            }
            DataContext = new OrderDetailsTableVM(orderId);
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Delete();
        }

        private void BtnSave_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Save(_customerId, _orderId);
        }
    }
}
