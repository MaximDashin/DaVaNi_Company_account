﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Customers.Orders
{
    /// <summary>
    /// Interaction logic for OrdersTablePage.xaml
    /// </summary>
    public partial class OrdersTablePage : Page
    {
        private int _customerId;
        public OrdersTablePage(int customerId)
        {
            InitializeComponent();

            _customerId = customerId;

            Title = "Клиент №" + customerId;
            txtbTableName.Text = "Клиент: " + (DataContext as OrdersTableVM).GetCustomerName(customerId);
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderDetailsTablePage(0, _customerId));
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as OrdersTableVM).Delete();
        }

        private void OrderDetails_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderDetailsTablePage((DataContext as OrdersTableVM).SelectedItem.Id));
        }
    }
}
