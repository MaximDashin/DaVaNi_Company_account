﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Customers
{
    /// <summary>
    /// Interaction logic for AddEditCustomerContactsWindow.xaml
    /// </summary>
    public partial class AddEditCustomerContactsWindow : Window
    {
        private readonly int _customerId;

        public AddEditCustomerContactsWindow(int customerId = 0)
        {
            InitializeComponent();
            if (customerId == 0)
            {
                btnConfirm.Content = "Добавить";
                Title = "Добавить заказчика";
            }
            else
            {
                _customerId = customerId;
                btnConfirm.Content = "Изменить";
                Title = "Изменить данные заказчика";
            }
            DataContext = new AddEditCustomerContactsVM(customerId);
        }

        public new AddEditCustomerContactsVM DataContext
        {
            get { return base.DataContext as AddEditCustomerContactsVM; }
            set { base.DataContext = value; }
        }


        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void btnConfirm_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_customerId);
        }

        private void btnAddOneMoreTelephoneNumber_OnClick(object sender, RoutedEventArgs e)
        {
            if (DataContext.TelephoneNumbers.Count < 3)
                DataContext.TelephoneNumbers.Add(new Telephone());
            if (DataContext.TelephoneNumbers.Count == 3)
                btnAddOneMoreTelephoneNumber.Visibility = Visibility.Collapsed;
        }
    }
}
