﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Suppliers
{
    /// <summary>
    /// Interaction logic for AddEditSupplierContactsWindow.xaml
    /// </summary>
    public partial class AddEditSupplierContactsWindow : Window
    {
        private readonly int _supplierId;
        public AddEditSupplierContactsWindow(int supplierId = 0)
        {
            InitializeComponent();
            if (supplierId == 0)
            {
                btnConfirm.Content = "Добавить";
                Title = "Добавить поставщика";
            }
            else
            {
                _supplierId = supplierId;
                btnConfirm.Content = "Изменить";
                Title = "Изменить данные поставщика";
            }
            DataContext = new AddEditSupplierContactsVM(supplierId);
        }

        public new AddEditSupplierContactsVM DataContext
        {
            get { return base.DataContext as AddEditSupplierContactsVM; }
            set { base.DataContext = value; }
        }

        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void btnConfirm_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_supplierId);
        }

        private void btnAddOneMoreTelephoneNumber_OnClick(object sender, RoutedEventArgs e)
        {
            if (DataContext.TelephoneNumbers.Count < 3)
                DataContext.TelephoneNumbers.Add(new Telephone());
            if (DataContext.TelephoneNumbers.Count == 3)
                btnAddOneMoreTelephoneNumber.Visibility = Visibility.Collapsed;
        }

    }
}
