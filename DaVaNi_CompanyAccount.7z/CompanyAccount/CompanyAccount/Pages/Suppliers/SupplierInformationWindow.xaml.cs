﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Suppliers
{
    /// <summary>
    /// Interaction logic for SupplierInformationWindow.xaml
    /// </summary>
    public partial class SupplierInformationWindow : Window
    {
        public new AddEditSupplierContactsVM DataContext
        {
            get { return base.DataContext as AddEditSupplierContactsVM; }
            set { base.DataContext = value; }
        }

        public SupplierInformationWindow(int supplierId)
        {
            InitializeComponent(); 
            DataContext = new AddEditSupplierContactsVM(supplierId);
        }

        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            int id = (DataContext as AddEditSupplierContactsVM).Id;
            AddEditSupplierContactsWindow window = new AddEditSupplierContactsWindow(id);
            Close();
            window.ShowDialog();
        }

    }
}
