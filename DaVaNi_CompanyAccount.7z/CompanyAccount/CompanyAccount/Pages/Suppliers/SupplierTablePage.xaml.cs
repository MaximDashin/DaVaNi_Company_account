﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Suppliers
{
    /// <summary>
    /// Interaction logic for SupplierTablePage.xaml
    /// </summary>
    public partial class SupplierTablePage : Page
    {
        public SupplierTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditSupplierContactsWindow window = new AddEditSupplierContactsWindow();
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as SupplierTableVM).Delete();
        }

        private void Contacts_OnClick(object sender, RoutedEventArgs e)
        {
            int id = (DataContext as SupplierTableVM).SelectedItem.Id;
            SupplierInformationWindow window = new SupplierInformationWindow(id) {Owner = Window.GetWindow(this)};
            window.Show();
        }

        private void SupplyDetails_OnClick(object sender, RoutedEventArgs e)
        {
            int id = (DataContext as SupplierTableVM).SelectedItem.Id;
            NavigationService.Navigate(new SupplyInformationPage(id));
        }
    }
}
