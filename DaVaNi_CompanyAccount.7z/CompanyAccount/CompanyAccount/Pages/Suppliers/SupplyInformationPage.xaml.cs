﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Suppliers
{
    /// <summary>
    /// Interaction logic for SupplyInformationPage.xaml
    /// </summary>
    public partial class SupplyInformationPage : Page
    {
        private readonly int _supplierId;

        public new SupplyInformationVM DataContext
        {
            get { return base.DataContext as SupplyInformationVM; }
            set { base.DataContext = value; }
        }

        public SupplyInformationPage(int supplierId)
        {
            InitializeComponent();

            _supplierId = supplierId;
            DataContext = new SupplyInformationVM(supplierId);

            Title = "Поставщик №" + supplierId;
            txtbTableName.Text = "Поставщик: " + DataContext.GetSupplierName(supplierId);
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditSupplyWindow window = new AddEditSupplyWindow(0, _supplierId);
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            int id = DataContext.SelectedItem.Id;
            AddEditSupplyWindow window = new AddEditSupplyWindow(id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Delete();
        }

    }
}
