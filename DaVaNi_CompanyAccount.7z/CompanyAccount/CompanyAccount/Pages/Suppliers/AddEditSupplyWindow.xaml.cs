﻿using System.Windows;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Suppliers
{
    /// <summary>
    /// Interaction logic for AddEditSupplyWindow.xaml
    /// </summary>
    public partial class AddEditSupplyWindow : Window
    {
        private readonly int _supplyId;
        private readonly int _supplierId;

        public AddEditSupplyWindow(int supplyId = 0, int supplierId = 0) //todo: добавить ид постащика
        {
            InitializeComponent();
            if (supplyId == 0)
            {
                _supplierId = supplierId;
                btnConfirm.Content = "Добавить";
                Title = "Добавить поставку";
            }
            else
            {
                _supplyId = supplyId;
                btnConfirm.Content = "Изменить";
                Title = "Изменить данные поставки";
            }
            DataContext = new AddEditSupplyVM(supplyId);
        }

        public new AddEditSupplyVM DataContext
        {
            get { return base.DataContext as AddEditSupplyVM; }
            set { base.DataContext = value; }
        }

        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnConfirm_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_supplyId, _supplierId);
        }
    }
}
