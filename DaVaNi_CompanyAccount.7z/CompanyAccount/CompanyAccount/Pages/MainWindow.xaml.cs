﻿using System;
using System.Windows;
using System.Windows.Input;

namespace CompanyAccount.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        #region Left panel controls event: OnClick
        private void LeftPanel_Product_OnClick(object sender, RoutedEventArgs e)
        {
            MainAreaFrame.Source = new Uri("Products/ProductPage.xaml", UriKind.Relative);
        }

        private void LeftPanel_Materials_OnClick(object sender, RoutedEventArgs e)
        {
            MainAreaFrame.Source = new Uri("Materials/MaterialsPage.xaml", UriKind.Relative);
        }

        private void LeftPanel_Customers_OnClick(object sender, RoutedEventArgs e)
        {
            MainAreaFrame.Source = new Uri("Customers/CustomersTablePage.xaml", UriKind.Relative);
        }

        private void LeftPanel_Supplier_OnClick(object sender, RoutedEventArgs e)
        {
            MainAreaFrame.Source = new Uri("Suppliers/SupplierTablePage.xaml", UriKind.Relative);
        }

        private void LeftPanel_Employee_OnClick(object sender, RoutedEventArgs e)
        {
            MainAreaFrame.Source = new Uri("Employees/EmployeeTablePage.xaml", UriKind.Relative);
        }
        #endregion

        #region Menu command OnExecuted
        private void CommandBinding_Print_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            
        }

        private void CommandBinding_Save_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {

        }

        private void CommandBinding_SaveAs_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {

        }

        private void CommandBinding_Close_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {

        }
        #endregion

        #region Menu command OnCanExecute
        private void CommandBinding_Print_OnCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {

        }

        private void CommandBinding_Save_OnCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {

        }

        private void CommandBinding_SaveAs_OnCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion


    }
}
