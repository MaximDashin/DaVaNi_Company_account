﻿using System.Windows;
using System.Windows.Input;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Логика взаимодействия для AddEditProduct.xaml
    /// </summary>
    public partial class AddEditProductWindow : Window
    {
        private readonly int _productId;

        public AddEditProductWindow(int productId = 0)
        {
            InitializeComponent();
            
            if (productId == 0)
            {
                btnAccept.Content = "Добавить";
                Title = "Добавить новое изделие";
            }
            else
            {
                _productId = productId;
                btnAccept.Content = "Изменить";
                Title = "Изменить изделие";
            }
            DataContext = new AddEditProductVM(productId);
        }

        public new AddEditProductVM DataContext
        {
            get { return base.DataContext as AddEditProductVM; }
            set { base.DataContext = value; }
        }


        #region Buttons
        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnAccept_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_productId);
        }
        #endregion

//todo: удалить нахуй и юзать нормальный WPF Validator
        #region Validation 
        private void TextBox_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1)) 
            {
                e.Handled = true;
            }
        }
        #endregion
    }
}
