﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Interaction logic for DestroyProductTablePage.xaml
    /// </summary>
    public partial class DestroyProductTablePage : Page
    {
        public DestroyProductTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow(
                (DataContext as DestroyProductTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as DestroyProductTableVM).Delete();
        }

        private void InformationChanges_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductsInformationChangesPage(
                (DataContext as DestroyProductTableVM).SelectedItem.ModelName, 
                (DataContext as DestroyProductTableVM).SelectedItem.Id));
        }
    }
}
