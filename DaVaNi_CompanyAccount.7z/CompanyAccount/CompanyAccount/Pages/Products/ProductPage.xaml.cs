﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        public ProductPage()
        {
            InitializeComponent();
        }

        #region Product Buttons event: OnClick
        private void ButtonProduct_Sheep_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Products/SheepProductTablePage.xaml", UriKind.Relative));
        }

        private void ButtonProduct_Cow_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Products/CowProductTablePage.xaml", UriKind.Relative));
        }

        private void ButtonProduct_Destroy_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Products/DestroyProductTablePage.xaml", UriKind.Relative));
        }

        private void ButtonProduct_Textile_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Products/TextileProductTablePage.xaml", UriKind.Relative));
        }

        private void ButtonProduct_All_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Pages/Products/AllProductTablePage.xaml", UriKind.Relative));
        }
        #endregion

    }
}
