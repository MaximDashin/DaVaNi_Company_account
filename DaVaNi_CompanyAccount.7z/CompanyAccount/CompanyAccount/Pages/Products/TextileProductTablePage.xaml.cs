﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Interaction logic for TextileProductTablePage.xaml
    /// </summary>
    public partial class TextileProductTablePage : Page
    {
        public TextileProductTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow(
                (DataContext as TextileProductTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as TextileProductTableVM).Delete();
        }

        private void InformationChanges_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductsInformationChangesPage(
                (DataContext as TextileProductTableVM).SelectedItem.ModelName,
                (DataContext as TextileProductTableVM).SelectedItem.Id));
        }
    }
}
