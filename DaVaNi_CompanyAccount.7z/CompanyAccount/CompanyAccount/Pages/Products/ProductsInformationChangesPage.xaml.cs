﻿using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Interaction logic for ProductsInformationChangesPage.xaml
    /// </summary>
    public partial class ProductsInformationChangesPage : Page
    {
        private int _productId;
        public ProductsInformationChangesPage(string title, int productId)
        {
            InitializeComponent();
            _productId = productId;
            txtbTableName.Text = title;
            DataContext = new ProductsInformationChangesVM(productId);
        }

        public new ProductsInformationChangesVM DataContext
        {
            get { return base.DataContext as ProductsInformationChangesVM; }
            set { base.DataContext = value; }
        }


    }
}
