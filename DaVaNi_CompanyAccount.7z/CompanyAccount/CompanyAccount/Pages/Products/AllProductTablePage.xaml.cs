﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Products
{
    /// <summary>
    /// Interaction logic for AllProductTablePage.xaml
    /// </summary>
    public partial class AllProductTablePage : Page
    {
        public AllProductTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow();
            window.ShowDialog();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditProductWindow window = new AddEditProductWindow(
                (DataContext as AllProductTableVM).SelectedItem.Id);
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as AllProductTableVM).Delete();
        }

        private void InformationChanges_OnClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductsInformationChangesPage(
                (DataContext as AllProductTableVM).SelectedItem.ModelName, 
                (DataContext as AllProductTableVM).SelectedItem.Id));
        }

    }
}
