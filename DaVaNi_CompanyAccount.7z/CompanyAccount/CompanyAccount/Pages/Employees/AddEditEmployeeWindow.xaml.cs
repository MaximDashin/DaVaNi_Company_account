﻿using System.Windows;
using CompanyAccount.ViewModel;
using Microsoft.Win32;

namespace CompanyAccount.Pages.Employees
{
    /// <summary>
    /// Interaction logic for AddEditEmployeeWindow.xaml
    /// </summary>
    public partial class AddEditEmployeeWindow : Window
    {
        private readonly int _employeeId;
        public AddEditEmployeeWindow(int employeeId = 0)
        {
            InitializeComponent();
            if (employeeId == 0)
            {
                btnConfirm.Content = "Добавить";
                Title = "Добавить работника";
            }
            else
            {
                _employeeId = employeeId;
                btnConfirm.Content = "Изменить";
                Title = "Изменить данные работника";
            }

            DataContext = new AddEditEmployeeVM(employeeId);
        }

        public new AddEditEmployeeVM DataContext
        {
            get { return base.DataContext as AddEditEmployeeVM; }
            set { base.DataContext = value; }
        }

        private void BtnCancel_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnConfirm_OnClick(object sender, RoutedEventArgs e)
        {
            DataContext.Confirm(_employeeId);
        }

        private void BtnAddDocumentPhoto_OnClick(object sender, RoutedEventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog { Multiselect = true };
            if (open.ShowDialog().GetValueOrDefault())
            {
                foreach (var fileName in open.FileNames)
                {
                    DataContext.AddNewDocument(fileName);
                }
            }
        }

        private void BtnDeletePhoto_OnClick(object sender, RoutedEventArgs e)
        {
            //todo: сделать удаление фоток
        }

        private void btnAddOneMoreTelephoneNumber_OnClick(object sender, RoutedEventArgs e)
        {
            if (DataContext.TelephoneNumbers.Count < 3)
                DataContext.TelephoneNumbers.Add(new Telephone());
            if (DataContext.TelephoneNumbers.Count == 3)
                btnAddOneMoreTelephoneNumber.Visibility = Visibility.Collapsed;
        }

    }
}
