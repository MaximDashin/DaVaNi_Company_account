﻿using System.Windows;
using System.Windows.Controls;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Pages.Employees
{
    /// <summary>
    /// Interaction logic for EmployeeTablePage.xaml
    /// </summary>
    public partial class EmployeeTablePage : Page
    {
        public EmployeeTablePage()
        {
            InitializeComponent();
        }

        private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditEmployeeWindow window = new AddEditEmployeeWindow();
            window.ShowDialog();
        }

        private void BtnDelete_OnClick(object sender, RoutedEventArgs e)
        {
            (DataContext as EmployeeTableVM).Delete();
        }

        private void Information_OnClick(object sender, RoutedEventArgs e)
        {
            EmployeeInformationWindow information =
                new EmployeeInformationWindow((DataContext as EmployeeTableVM).SelectedItem.Id)
                { Owner = Window.GetWindow(this) };
            information.Show();
        }
    }
}
