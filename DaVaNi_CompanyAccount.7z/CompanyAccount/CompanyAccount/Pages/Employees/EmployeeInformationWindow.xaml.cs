﻿using System.Windows;

namespace CompanyAccount.Pages.Employees
{
    /// <summary>
    /// Interaction logic for EmployeeInformationWindow.xaml
    /// </summary>
    public partial class EmployeeInformationWindow : Window
    {
        private readonly int _employeeId;
        public EmployeeInformationWindow(int empId)
        {
            InitializeComponent();
            _employeeId = empId;
        }

        private void BtnClose_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnEdit_OnClick(object sender, RoutedEventArgs e)
        {
            AddEditEmployeeWindow window = new AddEditEmployeeWindow(_employeeId);
            Close();
            window.ShowDialog();
        }
    }
}
