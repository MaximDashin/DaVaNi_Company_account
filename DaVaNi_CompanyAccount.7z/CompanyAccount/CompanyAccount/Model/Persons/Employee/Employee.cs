﻿using System;
using System.Collections.Generic;

namespace CompanyAccount.Model.Persons.Employee
{
    public class Employee : BasePerson
    {
        public DateTime EmploymentDate { get; set; }
        public string Post { get; set; }
        public int Salary { get; set; }
        public virtual ICollection<Photo> Documents { get; set; }

        public Employee()
        {
            Documents = new HashSet<Photo>();
        }
    }
}
