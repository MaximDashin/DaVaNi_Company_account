﻿namespace CompanyAccount.Model.Persons.Employee
{
    public class Photo
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public virtual Employee Employee { get; set; }
        public byte[] DataBytes { get; set; }
        public bool Deleted { get; set; }
        
    }
}