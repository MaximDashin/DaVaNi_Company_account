﻿namespace CompanyAccount.Model.Persons
{
    public class BasePersonWithContacts : BasePerson
    {
        public string Country { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string Skype { get; set; }
    }
}
