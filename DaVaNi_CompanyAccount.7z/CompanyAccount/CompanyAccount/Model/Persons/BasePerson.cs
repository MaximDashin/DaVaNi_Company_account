﻿using System.Collections.Generic;

namespace CompanyAccount.Model.Persons
{
    public class BasePerson
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<TelephoneNumber> TelephoneNumbers { get; set; }
        public bool Deleted { get; set; }

        public BasePerson()
        {
            TelephoneNumbers = new HashSet<TelephoneNumber>();
            Deleted = false;
        }
    }
}
