﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyAccount.Model.Persons.Supplier
{
    public class Supplier : BasePersonWithContacts
    {
        public virtual ICollection<Supply> Supplies { get; set; }

        public Supplier()
        {
            Supplies = new HashSet<Supply>();
        }
    }
}
