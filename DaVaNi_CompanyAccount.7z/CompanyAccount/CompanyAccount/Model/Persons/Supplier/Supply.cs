﻿namespace CompanyAccount.Model.Persons.Supplier
{
    public class Supply
    {
        public int Id { get; set; }
        public int SupplierId { get; set; }
        public virtual Supplier Supplier { get; set; }
        public string MaterialName { get; set; }
        public string Description { get; set; }
        public float Price { get; set; }
        public bool Deleted { get; set; }

        public Supply()
        {
            Deleted = false;
        }
    }
}