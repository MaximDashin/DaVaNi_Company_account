﻿using System;

namespace CompanyAccount.Model.Persons.Customer
{
    public class Order
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
        public string OrderNumber { get; set; }
        public string Model { get; set; }
        public int Quantity { get; set; }
        public float PriceForOne { get; set; }
        public float PriceForAll { get; set; }
        public DateTime OrderDate { get; set; }
        public bool Deleted { get; set; }
    }
}