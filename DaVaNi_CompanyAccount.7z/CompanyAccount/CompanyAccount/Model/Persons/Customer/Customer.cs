﻿using System.Collections.Generic;

namespace CompanyAccount.Model.Persons.Customer
{
    public class Customer : BasePersonWithContacts
    {
        public virtual ICollection<Order> Orders { get; set; }

        public Customer()
        {
            Orders = new HashSet<Order>();
        }
    }
}
