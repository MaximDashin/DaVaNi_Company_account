﻿using System;

namespace CompanyAccount.Model.Persons
{
    public class TelephoneNumber
    {
        public int Id { get; set; }
        public int? CustomerId { get; set; }
        public int? EmployeeId { get; set; }
        public int? SupplierId { get; set; }
        public virtual Customer.Customer Customer { get; set; }
        public virtual Employee.Employee Employee { get; set; }
        public virtual Supplier.Supplier Supplier { get; set; }
        public string TelNumber { get; set; }
    }
}