﻿using System;

namespace CompanyAccount.Model.Product
{
    public class InformationChanges
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public virtual Product Product { get; set; }
        public DateTime DateOfChanges { get; set; }
        public string DescriptionBefore { get; set; }
        public string DescriptionAfter { get; set; }
    }
}