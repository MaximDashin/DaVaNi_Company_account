﻿using System.Collections.Generic;

namespace CompanyAccount.Model.Product
{
    public class Product
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string ModelName { get; set; }
        public int M { get; set; }
        public int L { get; set; }
        public int XL { get; set; }
        public int XXL { get; set; }
        public string Material1 { get; set; }
        public string Material2 { get; set; }
        public float Price { get; set; }
        public bool Deleted { get; set; }
        
        public virtual ICollection<InformationChanges> Changes { get; set; }

        public Product()
        {
            Changes = new HashSet<InformationChanges>();
        }
    }
}
