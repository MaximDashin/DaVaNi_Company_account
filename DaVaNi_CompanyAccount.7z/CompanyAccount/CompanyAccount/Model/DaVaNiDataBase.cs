using System;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using CompanyAccount.Model.Material;
using CompanyAccount.Model.Persons;
using CompanyAccount.Model.Persons.Customer;
using CompanyAccount.Model.Persons.Employee;
using CompanyAccount.Model.Persons.Supplier;
using CompanyAccount.Model.Product;

namespace CompanyAccount.Model
{

    public class DaVaNiDataBase : DbContext
    {
        public DaVaNiDataBase() : base("name=DaVaNiConnection")
        {
        }

        public virtual DbSet<Material.Material> Material { get; set; }
        public virtual DbSet<MaterialParams> MaterialParams { get; set; }
        public virtual DbSet<MatType> MatType { get; set; }
        public virtual DbSet<ParamType> ParamType { get; set; }


        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Photo> Photos { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<Supply> Supplies { get; set; }
        public virtual DbSet<Product.Product> Products { get; set; }
        public virtual DbSet<InformationChanges> InformationChangeses { get; set; }
        public virtual DbSet<TelephoneNumber> TelephoneNumbers { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Material.Material>()
                .HasMany(e => e.MaterialParams)
                .WithRequired(e => e.Material)
                .WillCascadeOnDelete(false); // i think i need cascade

            modelBuilder.Entity<MatType>()
                .HasMany(e => e.Material)
                .WithRequired(e => e.MatType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MatType>()
                .HasMany(e => e.MaterialParams)
                .WithRequired(e => e.MatType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MatType>()
                .HasMany(e => e.ParamType)
                .WithMany(e => e.MatType)
                .Map(m => m.ToTable("MatParamType").MapLeftKey("MatTypeId").MapRightKey("ParamTypeId"));

            modelBuilder.Entity<ParamType>()
                .HasMany(e => e.MaterialParams)
                .WithRequired(e => e.ParamType)
                .WillCascadeOnDelete(false);


            //*************************************************

            //Product
            modelBuilder.Entity<Product.Product>()
                .HasMany(e => e.Changes)
                .WithRequired(e => e.Product);

            modelBuilder.Entity<Product.Product>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<InformationChanges>()
                .HasKey(e => new {e.Id, e.ProductId});

            modelBuilder.Entity<InformationChanges>()
                .Property(e => e.DateOfChanges)
                .HasColumnType("datetime2")
                .IsRequired();

            //Customer
            modelBuilder.Entity<Customer>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<Customer>()
                .HasMany(e => e.Orders)
                .WithRequired(e => e.Customer);

            modelBuilder.Entity<Customer>()
                .HasMany(e => e.TelephoneNumbers)
                .WithRequired(e => e.Customer);

            modelBuilder.Entity<Order>()
                .HasKey(e => new {e.Id, e.CustomerId});


            // tephone number
            modelBuilder.Entity<TelephoneNumber>()
                .HasKey(e => e.Id); 

            // employee
            modelBuilder.Entity<Employee>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.Documents)
                .WithRequired(e => e.Employee);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.TelephoneNumbers)
                .WithRequired(e => e.Employee);

            modelBuilder.Entity<Employee>()
                .Property(e => e.EmploymentDate)
                .HasColumnType("datetime2")
                .IsRequired();

            modelBuilder.Entity<Photo>()
                .HasKey(e => new { e.Id, e.EmployeeId});
            
            //supplier
            modelBuilder.Entity<Supplier>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<Supplier>()
                .HasMany(e => e.Supplies)
                .WithRequired(e => e.Supplier);

            modelBuilder.Entity<Supplier>()
                .HasMany(e => e.TelephoneNumbers)
                .WithRequired(e => e.Supplier);

            modelBuilder.Entity<Supply>()
                .HasKey(e => new {e.Id, e.SupplierId});



        }
    }
}
