using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Spatial;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.Model.Material
{
    [Table("ParamType")]
    public class ParamType
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ParamType()
        {
            MaterialParams = new HashSet<MaterialParams>();
            MatType = new HashSet<MatType>();
        }

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public ParamTypeId ParamTypeId { get; set; }

        [Required]
        [StringLength(100)]
        public string ParamTypeProp { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MaterialParams> MaterialParams { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MatType> MatType { get; set; }
    }
}
