using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.Model.Material
{
    [Table("Material")]
    public class Material
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Material()
        {
            MaterialParams = new HashSet<MaterialParams>();
            Deleted = false;
        }

        public int MaterialId { get; set; }

        public MatTypeId MatTypeId { get; set; }

        public virtual MatType MatType { get; set; }

        public bool Deleted { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MaterialParams> MaterialParams { get; set; }
    }
}
