using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.Model.Material
{
    [Table("MatType")]
    public class MatType
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public MatType()
        {
            Material = new HashSet<Material>();
            MaterialParams = new HashSet<MaterialParams>();
            ParamType = new HashSet<ParamType>();
        }

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public MatTypeId MatTypeId { get; set; }

        [Required]
        [StringLength(100)]
        public string MatTypeName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Material> Material { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<MaterialParams> MaterialParams { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ParamType> ParamType { get; set; }
    }
}
