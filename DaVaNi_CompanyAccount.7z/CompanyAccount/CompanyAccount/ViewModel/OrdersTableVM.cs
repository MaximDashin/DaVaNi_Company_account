﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using AutoMapper.QueryableExtensions;
using CompanyAccount.Annotations;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class OrdersTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<OrdersTable> Items { get; set; }
        public OrdersTable SelectedItem { get; set; }

        public OrdersTableVM()
        {
            Items = new ObservableCollection<OrdersTable>(context.Orders.Where(e => !e.Deleted)
                                                    .ProjectTo<OrdersTable>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Orders.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public string GetCustomerName(int id)
        {
            return context.Customers.Single(e => e.Id == id).Name;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class OrdersTable : INotifyPropertyChanged
    {
        private int _id;
        private int _customerId;
        private string _orderNumber;
        private DateTime _date;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public int CustomerId
        {
            get { return _customerId; }
            set
            {
                if (value == _customerId) return;
                _customerId = value;
                OnPropertyChanged();
            }
        }
        public string OrderNumber
        {
            get { return _orderNumber; }
            set
            {
                if (value == _orderNumber) return;
                _orderNumber = value;
                OnPropertyChanged();
            }
        }
        public DateTime Date
        {
            get { return _date; }
            set
            {
                if (value.Equals(_date)) return;
                _date = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
