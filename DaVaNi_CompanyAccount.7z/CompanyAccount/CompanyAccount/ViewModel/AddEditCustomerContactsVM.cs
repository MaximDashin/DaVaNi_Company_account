﻿using System.Collections.ObjectModel;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditCustomerContactsVM
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public ObservableCollection<Telephone> TelephoneNumbers { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string Skype { get; set; }

        private readonly AddEditCustomerContactsService _service;

        public AddEditCustomerContactsVM():this(0){}

        public AddEditCustomerContactsVM(int id)
        {
            _service = new AddEditCustomerContactsService(App.Mapper.ConfigurationProvider);
            if (id == 0)
                TelephoneNumbers = new ObservableCollection<Telephone>(new[]
                {new Telephone { TelNumber = ""}});
            else
                GetCustomerById(id);
        }

        public void AddCustomer()
        {
            var item = GetItem();

            _service.Insert(item);
        }

        public void EditCustomer()
        {
            var item = GetItem();

            _service.Update(item);
        }

        public void GetCustomerById(int id)
        {
            var customer = _service.GetById(id);

            Id = customer.Id;
            Name = customer.Name;
            TelephoneNumbers = new ObservableCollection<Telephone>(customer.TelephoneNumbers);
            Country = customer.Country;
            City = customer.City;
            Email = customer.Email;
            Skype = customer.Skype;
        }

        public void Confirm(int id)
        {
            if (id == 0)
                AddCustomer();
            else
                EditCustomer();
        }

        private AddEditCustomerContactsVM GetItem()
        {
            AddEditCustomerContactsVM item = new AddEditCustomerContactsVM
            {
                Id = Id,
                Name = Name,
                TelephoneNumbers = new ObservableCollection<Telephone>(TelephoneNumbers),
                Country = Country,
                City = City,
                Email = Email,
                Skype = Skype
            };
            return item;
        }
    }

    public class Telephone
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public string TelNumber { get; set; }
    }
}
