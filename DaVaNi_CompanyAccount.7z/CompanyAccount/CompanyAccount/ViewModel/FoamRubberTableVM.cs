﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using CompanyAccount.ViewModel.Plagin;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class FoamRubberTableVM : INotifyPropertyChanged
    {
        public ObservableCollection<FoamRubberTable> Items { get; set; }
        public FoamRubberTable SelectedItem { get; set; }

        private readonly MaterialsService _service;

        public FoamRubberTableVM()
        {
            _service = new MaterialsService();
            Items = new ObservableCollection<FoamRubberTable>(_service.GetFoamRubberMaterials());
        }

        public void Delete()
        {
            _service.Delete(SelectedItem.Id);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class FoamRubberTable : INotifyPropertyChanged
    {
        private int _id;
        private string _materialName;
        private string _quality;
        private string _quantity;
        private string _size;
        private string _thickness;
        private string _price;
        private string _supplier;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public string MaterialName
        {
            get { return _materialName; }
            set
            {
                if (value == _materialName) return;
                _materialName = value;
                OnPropertyChanged();
            }
        }
        public string Quality
        {
            get { return _quality; }
            set
            {
                if (value == _quality) return;
                _quality = value;
                OnPropertyChanged();
            }
        }
        public string Quantity
        {
            get { return _quantity; }
            set
            {
                if (value == _quantity) return;
                _quantity = value;
                OnPropertyChanged();
            }
        }
        public string Size
        {
            get { return _size; }
            set
            {
                if (value == _size) return;
                _size = value;
                OnPropertyChanged();
            }
        }
        public string Thickness
        {
            get { return _thickness; }
            set
            {
                if (value.Equals(_thickness)) return;
                _thickness = value;
                OnPropertyChanged();
            }
        }
        public string Price
        {
            get { return _price; }
            set
            {
                if (value.Equals(_price)) return;
                _price = value;
                OnPropertyChanged();
            }
        }
        public string Supplier
        {
            get { return _supplier; }
            set
            {
                if (value == _supplier) return;
                _supplier = value;
                OnPropertyChanged();
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
