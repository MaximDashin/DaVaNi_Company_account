﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using AutoMapper.QueryableExtensions;
using CompanyAccount.Annotations;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class DestroyProductTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<DestroyProductTable> Items { get; set; }
        public DestroyProductTable SelectedItem { get; set; }

        public DestroyProductTableVM()
        {
            Items = new ObservableCollection<DestroyProductTable>(context.Products.Where(e => !e.Deleted && e.Type == "Destroy")
                                                                .ProjectTo<DestroyProductTable>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Products.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class DestroyProductTable : INotifyPropertyChanged
    {
        private int _id;
        private string _modelName;
        private int _m;
        private int _l;
        private int _xl;
        private int _xxl;
        private string _material1;
        private string _material2;
        private float _price;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public string Type => "Destroy";
        public string ModelName
        {
            get { return _modelName; }
            set
            {
                if (value == _modelName) return;
                _modelName = value;
                OnPropertyChanged();
            }
        }
        public int M
        {
            get { return _m; }
            set
            {
                if (value == _m) return;
                _m = value;
                OnPropertyChanged();
            }
        }
        public int L
        {
            get { return _l; }
            set
            {
                if (value == _l) return;
                _l = value;
                OnPropertyChanged();
            }
        }
        public int XL
        {
            get { return _xl; }
            set
            {
                if (value == _xl) return;
                _xl = value;
                OnPropertyChanged();
            }
        }
        public int XXL
        {
            get { return _xxl; }
            set
            {
                if (value == _xxl) return;
                _xxl = value;
                OnPropertyChanged();
            }
        }
        public string Material1
        {
            get { return _material1; }
            set
            {
                if (value == _material1) return;
                _material1 = value;
                OnPropertyChanged();
            }
        }
        public string Material2
        {
            get { return _material2; }
            set
            {
                if (value == _material2) return;
                _material2 = value;
                OnPropertyChanged();
            }
        }
        public float Price
        {
            get { return _price; }
            set
            {
                if (value.Equals(_price)) return;
                _price = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
