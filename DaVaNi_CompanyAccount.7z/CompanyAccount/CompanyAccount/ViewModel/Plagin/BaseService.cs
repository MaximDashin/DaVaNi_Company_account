using System;
using CompanyAccount.Model;

namespace CompanyAccount.ViewModel.Plagin
{
    public abstract class BaseService : IDisposable
    {
        protected DaVaNiDataBase context;

        public BaseService()
        {
            context = new DaVaNiDataBase();
        }


        #region Dispose

        public virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                context.Dispose();
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }

        ~BaseService()
        {
            Dispose(false);
        }

        #endregion

    }
}