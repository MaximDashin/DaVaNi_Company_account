﻿using System;
using System.Linq.Expressions;
using System.Reflection;

namespace CompanyAccount.ViewModel.Plagin
{
    /// <summary>
    /// Extentions to bulk properties copy
    /// </summary>
    public static class CopyExtentions
    {
        /// <summary>
        /// Copy properties from one object to another
        /// </summary>
        /// <typeparam name="T">Type what want to copy</typeparam>
        /// <param name="from">From object</param>
        /// <param name="to">To object</param>
        /// <param name="properties">List of properties</param>
        public static void Copy<T>(this T from, T to, params Expression<Func<T, object>>[] properties)
        {

            foreach (var property in properties)
            {
                PropertyInfo prop;
                if (property.Body is MemberExpression)
                {
                    prop = (PropertyInfo)((MemberExpression)property.Body).Member;
                }
                else
                {
                    var op = ((UnaryExpression)property.Body).Operand;
                    prop = (PropertyInfo)((MemberExpression)op).Member;
                }
                prop.SetValue(to, prop.GetValue(from), null);

            }

        }

        /// <summary>
        /// Copy properties from one object to another with checking of changed values
        /// </summary>
        /// <typeparam name="T">Type what want to copy</typeparam>
        /// <param name="from">From object</param>
        /// <param name="to">To object</param>
        /// <param name="properties">List of properties</param>
        public static bool CopyWithChecking<T>(this T from, T to, params Expression<Func<T, object>>[] properties)
        {
            var isChanged = false;
            foreach (var property in properties)
            {
                PropertyInfo prop;
                if (property.Body is MemberExpression)
                {
                    prop = (PropertyInfo)((MemberExpression)property.Body).Member;
                }
                else
                {
                    var op = ((UnaryExpression)property.Body).Operand;
                    prop = (PropertyInfo)((MemberExpression)op).Member;
                }

                if (prop.GetValue(from) != prop.GetValue(to))
                {
                    isChanged = true;
                    prop.SetValue(to, prop.GetValue(from), null);
                }
            }
            return isChanged;
        }
    }
}