﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;

namespace CompanyAccount.ViewModel
{
    public class AddEditMaterialsVM : INotifyPropertyChanged
    {
        public AddEditMaterialsVM()
        {
            Suppliers = new ObservableCollection<Supplier123>();

            Materials = new ObservableCollection<Material123>
            {
                new Material123 {Id = MyMaterialEnum.Textile, Name = "Текстиль"},
                new Material123 {Id = MyMaterialEnum.Leather, Name = "Кожа"},
                new Material123 {Id = MyMaterialEnum.Fur, Name = "Мех"},
                new Material123 {Id = MyMaterialEnum.Lining, Name = "Подкладка"},
                new Material123 {Id = MyMaterialEnum.Latex, Name = "Латекс"},
                new Material123 {Id = MyMaterialEnum.FoamRubber, Name = "Поролон"},
                new Material123 {Id = MyMaterialEnum.Sintepon, Name = "Синтепон"},
                new Material123 {Id = MyMaterialEnum.Visor, Name = "Козырьки"},
                new Material123 {Id = MyMaterialEnum.Thread, Name = "Нитки"}
            };

            _materialTypes = new HashSet<MaterialType>
            {
                new MaterialType {Id = MyMaterialTypeEnum.Wool, Name = "Шерсть"},
                new MaterialType {Id = MyMaterialTypeEnum.RaincoatFabric, Name = "Плащевка"},
                new MaterialType {Id = MyMaterialTypeEnum.Sheep, Name = "Овчина"},
                new MaterialType {Id = MyMaterialTypeEnum.Cow, Name = "Телятина"},
                new MaterialType {Id = MyMaterialTypeEnum.Destroy, Name = "Дестрой"}
            };

            MaterialTypes = new ObservableCollection<MaterialType>();
        }

        public ObservableCollection<Material123> Materials { get; set; }
        public ObservableCollection<MaterialType> MaterialTypes { get; set; }

        private Material123 _material;
        private MaterialType _materialType;
        private int _type;
        private string _number;
        private string _materialName;
        private string _modelForVisor;
        private string _visorLenght;
        private string _color;
        private string _quality;
        private string _quantity;
        private string _howManyMeters;
        private string _thickness;
        private string _price;
        private HashSet<MaterialType> _materialTypes;
        private Supplier123 _selectedSupplier;

        public int Id { get; set; }
        public Material123  Material         
        {
            get { return _material; }
            set
            {
                if (Equals(value, _material)) return;
                _material = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(MaterialTypeShowModel));
                OnPropertyChanged(nameof(TypeShowModel));
                OnPropertyChanged(nameof(NumberShowModel));
                OnPropertyChanged(nameof(MaterialNameShowModel));
                OnPropertyChanged(nameof(ModelForVisorShowModel));
                OnPropertyChanged(nameof(VisorLenghtShowModel));
                OnPropertyChanged(nameof(ColorShowModel));
                OnPropertyChanged(nameof(QualityShowModel));
                OnPropertyChanged(nameof(QuantityShowModel));
                OnPropertyChanged(nameof(HowManyMetersShowModel));
                OnPropertyChanged(nameof(ThicknessShowModel));
                OnPropertyChanged(nameof(PriceShowModel));
                OnPropertyChanged(nameof(SupplierShowModel));
                ProcessMaterialTypes();
            }
        }
        public MaterialType MaterialType     
        {
            get { return _materialType; }
            set
            {
                if (Equals(value, _materialType)) return;
                _materialType = value;
                OnPropertyChanged();
            }
        }
        public int          Type             
        {
            get { return _type; }
            set
            {
                if (Equals(value, _type)) return;
                _type = value;
                OnPropertyChanged();
            }
        }
        public string       Number           
        {
            get { return _number; }
            set
            {
                if (Equals(value, _number)) return;
                _number = value;
                OnPropertyChanged();
            }
        }
        public string       MaterialName     
        {
            get { return _materialName; }
            set
            {
                if (Equals(value, _materialName)) return;
                _materialName = value;
                OnPropertyChanged();
            }
        }
        public string       ModelForVisor    
        {
            get { return _modelForVisor; }
            set
            {
                if (Equals(value, _modelForVisor)) return;
                _modelForVisor = value;
                OnPropertyChanged();
            }
        }
        public string       VisorLenght      
        {
            get { return _visorLenght; }
            set
            {
                if (Equals(value, _visorLenght)) return;
                _visorLenght = value;
                OnPropertyChanged();
            }
        }
        public string       Color            
        {
            get { return _color; }
            set
            {
                if (Equals(value, _color)) return;
                _color = value;
                OnPropertyChanged();
            }
        }
        public string       Quality          
        {
            get { return _quality; }
            set
            {
                if (Equals(value, _quality)) return;
                _quality = value;
                OnPropertyChanged();
            }
        }
        public string       Quantity         
        {
            get { return _quantity; }
            set
            {
                if (Equals(value, _quantity)) return;
                _quantity = value;
                OnPropertyChanged();
            }
        }
        public string       HowManyMeters       
        {
            get { return _howManyMeters; }
            set
            {
                if (Equals(value, _howManyMeters)) return;
                _howManyMeters = value;
                OnPropertyChanged();
            }
        }
        public string       Thickness           
        {
            get { return _thickness; }
            set
            {
                if (Equals(value, _thickness)) return;
                _thickness = value;
                OnPropertyChanged();
            }
        }
        public string       Price               
        {
            get { return _price; }
            set
            {
                if (Equals(value, _price)) return;
                _price = value;
                OnPropertyChanged();
            }
        }
        public Supplier123  SelectedSupplier 
        {
            get { return _selectedSupplier; }
            set
            {
                if (Equals(value, _selectedSupplier)) return;
                _selectedSupplier = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<Supplier123> Suppliers { get; set; }

        public bool MaterialTypeShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool TypeShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool NumberShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool MaterialNameShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.Latex:
                    case MyMaterialEnum.FoamRubber:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool ModelForVisorShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool VisorLenghtShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool ColorShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool QualityShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool QuantityShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.Latex:
                    case MyMaterialEnum.FoamRubber:
                    case MyMaterialEnum.Sintepon:
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool HowManyMetersShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool ThicknessShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Latex:
                    case MyMaterialEnum.FoamRubber:
                    case MyMaterialEnum.Sintepon:
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool PriceShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.Latex:
                    case MyMaterialEnum.FoamRubber:
                    case MyMaterialEnum.Sintepon:
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool SupplierShowModel
        {
            get
            {
                if (Material == null) return false;
                switch (Material.Id)
                {
                    case MyMaterialEnum.Textile:
                    case MyMaterialEnum.Leather:
                    case MyMaterialEnum.Fur:
                    case MyMaterialEnum.Lining:
                    case MyMaterialEnum.Latex:
                    case MyMaterialEnum.FoamRubber:
                    case MyMaterialEnum.Sintepon:
                    case MyMaterialEnum.Visor:
                    case MyMaterialEnum.Thread:
                    case MyMaterialEnum.None:
                        return true;
                    default:
                        return false;
                }
            }
        }


        private void ProcessMaterialTypes()
        {
            MyMaterialTypeEnum[] items;
            switch (Material.Id)
            {
                case MyMaterialEnum.Textile:
                    {
                        items = new[] { MyMaterialTypeEnum.Wool, MyMaterialTypeEnum.RaincoatFabric };
                        break;
                    }
                case MyMaterialEnum.Leather:
                case MyMaterialEnum.Fur:
                    {
                        items = new[] { MyMaterialTypeEnum.Sheep, MyMaterialTypeEnum.Cow, MyMaterialTypeEnum.Destroy };
                        break;
                    }
                default:
                    items = new MyMaterialTypeEnum[0];
                    break;
            }
            AddItems(items);
            RemoveItems(items);
            MaterialType = MaterialTypes.FirstOrDefault();
        }

        private void RemoveItems(IEnumerable<MyMaterialTypeEnum> ids)
        {
            var items = ((MyMaterialTypeEnum[])Enum.GetValues(typeof(MyMaterialTypeEnum))).Where(e => !ids.Contains(e));
            foreach (var id in items)
            {
                var item = _materialTypes.SingleOrDefault(e => e.Id == id);
                if (item != null && MaterialTypes.Contains(item))
                {
                    MaterialTypes.Remove(item);
                }
            }
        }

        private void AddItems(IEnumerable<MyMaterialTypeEnum> ids)
        {
            foreach (var id in ids)
            {
                var item = _materialTypes.SingleOrDefault(e => e.Id == id);
                if (item != null && !MaterialTypes.Contains(item))
                {
                    MaterialTypes.Add(item);
                }
            }
        }


        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

    }

    public enum MyMaterialEnum
    {
        Textile,
        Leather,
        Fur,
        Lining,
        Latex,
        FoamRubber,
        Sintepon,
        Visor,
        Thread,
        None
    }

    public enum MyMaterialTypeEnum
    {
        Wool,
        RaincoatFabric,
        Sheep,
        Cow,
        Destroy,
        None
    }


    public class Material123
    {
        public MyMaterialEnum Id { get; set; }

        public string Name { get; set; }
    }

    public class MaterialType
    {
        public MyMaterialTypeEnum Id { get; set; }

        public string Name { get; set; }
    }

    public class Supplier123
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
