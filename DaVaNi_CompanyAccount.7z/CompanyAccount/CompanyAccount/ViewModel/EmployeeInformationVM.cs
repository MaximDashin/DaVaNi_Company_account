﻿using System;
using System.Collections.ObjectModel;
using CompanyAccount.ViewModel.Service;


namespace CompanyAccount.ViewModel
{
    public class EmployeeInformationVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ObservableCollection<Telephone> TelephoneNumbers { get; set; }
        public DateTime EmploymentDate { get; set; }
        public string Post { get; set; }
        public int Salary { get; set; }
        public ObservableCollection<AddEditEmployeeVM.Document> Documents { get; set; }
        public AddEditEmployeeVM.Document SelectedDocument { get; set; }

        public EmployeeInformationVM(){}

        public EmployeeInformationVM(int id)
        {
            AddEditEmployeeService service = new AddEditEmployeeService(App.Mapper.ConfigurationProvider);
            var item = service.GetById(id);

            Id = item.Id;
            Name = item.Name;
            TelephoneNumbers = new ObservableCollection<Telephone>(item.TelephoneNumbers);
            EmploymentDate = item.EmploymentDate;
            Post = item.Post;
            Salary = item.Salary;
            Documents = new ObservableCollection<AddEditEmployeeVM.Document>(item.Documents);
        }
    }
}
