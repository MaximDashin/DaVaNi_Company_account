﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using CompanyAccount.ViewModel.Plagin;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditMaterialVM_new : BaseService, INotifyPropertyChanged
    {
        private readonly MaterialsService _materialsService;

        public ObservableCollection<IParamValue> ParamValues { get; set; }
        public ObservableCollection<MatName> MaterialNames { get; set; }
        public MatName SelectedMaterial { get; set; }

        public AddEditMaterialVM_new():this(0){}

        public AddEditMaterialVM_new(int id = 0)
        {
            _materialsService = new MaterialsService();
            if (id == 0)
            {
                MaterialNames = new ObservableCollection<MatName>(_materialsService.GetMaterialNames());
                ParamValues = new ObservableCollection<IParamValue>(_materialsService.GetParamsForNewMaterial(SelectedMaterial.Id));
            }
            else
            {
                var item = context.Material.Single(e => e.MaterialId == id);
                MaterialNames = new ObservableCollection<MatName>(_materialsService.GetMaterialNames());
                SelectedMaterial = MaterialNames.SingleOrDefault(e => e.Id == item.MatTypeId);
                ParamValues = new ObservableCollection<IParamValue>(_materialsService.GetParamsForMaterial(id));
            }
        }

        public void AddMaterial()
        {
            _materialsService.AddMaterial(ParamValues, SelectedMaterial.Id);
        }

        public void EditMaterial(int materialId)
        {
            foreach (var value in ParamValues)
            {
                _materialsService.UpdateParamValue(materialId, value);
            }
        }

        public void Confirm(int id)
        {
            if (id == 0)
                AddMaterial();
            else
                EditMaterial(id);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public interface IParamValue
    {
        ParamTypeId ParametrId { get; set; }
        string ParametrName { get; set; }
        string ParametrValue { get; set; }
    }

    public class TextParamValue:IParamValue
    {
        public ParamTypeId ParametrId { get; set; }
        public string ParametrName { get; set; }
        public string ParametrValue { get; set; }
    }

    public class DropdownParamValue:IParamValue
    {
        public DropdownParamValue(IEnumerable<string> items)
        {
            Items = items;
        }

        public ParamTypeId ParametrId { get; set; }
        public string ParametrName { get; set; }
        public string ParametrValue { get; set; }

        public IEnumerable<string> Items { get; set; }
    }
    
    public class RadiobuttonParamValue : IParamValue
    {
        public RadiobuttonParamValue(IEnumerable<string> items)
        {
            Items = items;
        }

        public ParamTypeId ParametrId { get; set; }
        public string ParametrName { get; set; }
        public string ParametrValue { get; set; }

        public IEnumerable<string> Items { get; set; }
    }

    public class MatName
    {
        public MatTypeId Id { get; set; }
        public string Name { get; set; }
    }
}
