﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using System.Linq;
using AutoMapper.QueryableExtensions;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class SupplyInformationVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<SupplyInformation> Items { get; set; }
        public SupplyInformation SelectedItem { get; set; }

        public SupplyInformationVM() : this(0) { }

        public SupplyInformationVM(int id)
        {
            Items = new ObservableCollection<SupplyInformation>(context.Supplies.Where(e => e.SupplierId == id)
                                  .ProjectTo<SupplyInformation>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Supplies.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public string GetSupplierName(int id)
        {
            return context.Suppliers.Single(e => e.Id == id).Name;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class SupplyInformation : INotifyPropertyChanged
    {
        private int _id;
        private int _supplierId;
        private string _materialName;
        private string _description;
        private float _price;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public int SupplierId
        {
            get { return _supplierId; }
            set
            {
                if (value == _supplierId) return;
                _supplierId = value;
                OnPropertyChanged();
            }
        }
        public string MaterialName
        {
            get { return _materialName; }
            set
            {
                if (value == _materialName) return;
                _materialName = value;
                OnPropertyChanged();
            }
        }
        public string Description
        {
            get { return _description; }
            set
            {
                if (value == _description) return;
                _description = value;
                OnPropertyChanged();
            }
        }
        public float Price
        {
            get { return _price; }
            set
            {
                if (value.Equals(_price)) return;
                _price = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
