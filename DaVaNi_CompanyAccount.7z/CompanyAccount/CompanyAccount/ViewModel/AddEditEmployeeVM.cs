﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditEmployeeVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ObservableCollection<Telephone> TelephoneNumbers { get; set; }
        public DateTime EmploymentDate { get; set; }
        public string Post { get; set; }
        public int Salary { get; set; }
        public ObservableCollection<Document> Documents { get; set; }

        private readonly AddEditEmployeeService _service;

        public AddEditEmployeeVM():this(0){}

        public AddEditEmployeeVM(int id)
        {
            _service = new AddEditEmployeeService(App.Mapper.ConfigurationProvider);
            if (id == 0)
            {
                TelephoneNumbers = new ObservableCollection<Telephone>(new[] 
                    { new Telephone { TelNumber = "" } });
                EmploymentDate = DateTime.Now;
                Documents = new ObservableCollection<Document>();
            }
            else
                GetEmployeeById(id);
        }

        public void AddEmployee()
        {
            var item = GetItem();

            _service.Insert(item);
        }

        public void EditEmployee()
        {
            var item = GetItem();

            _service.Update(item);
        }

        public void GetEmployeeById(int id)
        {
            var employee = _service.GetById(id);

            Id = employee.Id;
            Name = employee.Name;
            TelephoneNumbers = new ObservableCollection<Telephone>(employee.TelephoneNumbers);
            EmploymentDate = employee.EmploymentDate;
            Post = employee.Post;
            Salary = employee.Salary;
            Documents = new ObservableCollection<Document>(employee.Documents);
        }

        public void Confirm(int id)
        {
            if (id == 0)
                AddEmployee();
            else
                EditEmployee();
        }

        private AddEditEmployeeVM GetItem()
        {
            AddEditEmployeeVM item = new AddEditEmployeeVM
            {
                Id = Id,
                Name = Name,
                TelephoneNumbers = new ObservableCollection<Telephone>(TelephoneNumbers),
                EmploymentDate = EmploymentDate,
                Post = Post,
                Salary = Salary,
                Documents = new ObservableCollection<Document>(Documents)
            };
            return item;
        }

        public class Document
        {
            public int Id { get; set; }
            public int EmployeeId { get; set; }
            public byte[] Data { get; set; }
            public string Name { get; set; }
        }

        public void AddNewDocument(string fileName)
        {
            var bytes = File.ReadAllBytes(fileName);
            Documents.Add(new Document
            {
                Data = bytes,
                Name = "Photo "+Documents.Count + 1
            });
        }

    }


}
