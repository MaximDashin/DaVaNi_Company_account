﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using System.Linq;
using AutoMapper.QueryableExtensions;
using CompanyAccount.Model;
using CompanyAccount.ViewModel.Plagin;


namespace CompanyAccount.ViewModel
{
    public class CustomerTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<CustomerTable> Items { get; set; }
        public CustomerTable SelectedItem { get; set; }

        public CustomerTableVM()
        {
            Items = new ObservableCollection<CustomerTable>(context.Customers.Where(e => !e.Deleted)
                                                                .ProjectTo<CustomerTable>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Customers.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class CustomerTable : INotifyPropertyChanged
    {
        private int _id;
        private string _name;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name) return;
                _name = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
