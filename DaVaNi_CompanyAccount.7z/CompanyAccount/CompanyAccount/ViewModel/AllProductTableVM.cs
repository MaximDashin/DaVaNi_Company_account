﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using System.Linq;
using AutoMapper.QueryableExtensions;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class AllProductTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<AllProductTable> Items { get; set; }
        public AllProductTable SelectedItem { get; set; }

        public AllProductTableVM()
        {
            Items = new ObservableCollection<AllProductTable>(context.Products.Where(e => !e.Deleted)
                                                                .ProjectTo<AllProductTable>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Products.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class AllProductTable : INotifyPropertyChanged
    {
        private int _id;
        private string _type;
        private string _modelName;
        private int _m;
        private int _l;
        private int _xl;
        private int _xxl;
        private string _material1;
        private string _material2;
        private float _price;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public string Type
        {
            get { return _type; }
            set
            {
                if (value == _type) return;
                _type = value;
                OnPropertyChanged();
            }
        }
        public string ModelName
        {
            get { return _modelName; }
            set
            {
                if (value == _modelName) return;
                _modelName = value;
                OnPropertyChanged();
            }
        }
        public int M
        {
            get { return _m; }
            set
            {
                if (value == _m) return;
                _m = value;
                OnPropertyChanged();
            }
        }
        public int L
        {
            get { return _l; }
            set
            {
                if (value == _l) return;
                _l = value;
                OnPropertyChanged();
            }
        }
        public int XL
        {
            get { return _xl; }
            set
            {
                if (value == _xl) return;
                _xl = value;
                OnPropertyChanged();
            }
        }
        public int XXL
        {
            get { return _xxl; }
            set
            {
                if (value == _xxl) return;
                _xxl = value;
                OnPropertyChanged();
            }
        }
        public string Material1
        {
            get { return _material1; }
            set
            {
                if (value == _material1) return;
                _material1 = value;
                OnPropertyChanged();
            }
        }
        public string Material2
        {
            get { return _material2; }
            set
            {
                if (value == _material2) return;
                _material2 = value;
                OnPropertyChanged();
            }
        }
        public float Price
        {
            get { return _price; }
            set
            {
                if (value.Equals(_price)) return;
                _price = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
