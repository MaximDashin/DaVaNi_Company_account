﻿using System.Collections.ObjectModel;
using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditSupplierContactsVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ObservableCollection<Telephone> TelephoneNumbers { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string Skype { get; set; }

        private readonly AddEditSupplierService _service;

        public AddEditSupplierContactsVM():this(0){ }

        public AddEditSupplierContactsVM(int id)
        {
            _service = new AddEditSupplierService(App.Mapper.ConfigurationProvider);
            if (id == 0)
                TelephoneNumbers = new ObservableCollection<Telephone>(new[]
                {new Telephone { TelNumber = ""}});
            else
                GetSupplierById(id);
        }

        public void AddSupplier()
        {
            var item = GetItem();

            _service.Insert(item);

        }

        public void EditSupplier()
        {
            var item = GetItem();

            _service.Update(item);

        }

        public void Confirm(int id)
        {
            if (id == 0)
                AddSupplier();
            else
                EditSupplier();
        }

        public void GetSupplierById(int id)
        {
            var supplier = _service.GetById(id);

            Id = supplier.Id;
            Name = supplier.Name;
            TelephoneNumbers = new ObservableCollection<Telephone>(supplier.TelephoneNumbers);
            Country = supplier.Country;
            City = supplier.City;
            Email = supplier.Email;
            Skype = supplier.Skype;
        }

        private AddEditSupplierContactsVM GetItem()
        {
            AddEditSupplierContactsVM item = new AddEditSupplierContactsVM
            {
                Id = Id,
                Name = Name,
                TelephoneNumbers = new ObservableCollection<Telephone>(TelephoneNumbers),
                Country = Country,
                City = City,
                Email = Email,
                Skype = Skype
            };
            return item;
        }
    }
}
