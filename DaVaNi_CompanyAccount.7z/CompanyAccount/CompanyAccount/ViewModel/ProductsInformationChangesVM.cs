﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using CompanyAccount.ViewModel.Plagin;
using System.Linq;
using AutoMapper.QueryableExtensions;

namespace CompanyAccount.ViewModel
{
    public class ProductsInformationChangesVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<ProductsInformationChanges> Items { get; set; }
        public ProductsInformationChanges SelectedItem { get; set; }

        public ProductsInformationChangesVM() { }
        public ProductsInformationChangesVM(int id)
        {
            Items = new ObservableCollection<ProductsInformationChanges>(context.InformationChangeses.Where(e => e.ProductId == id)
                                                                .ProjectTo<ProductsInformationChanges>(App.Mapper.ConfigurationProvider));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    public class ProductsInformationChanges : INotifyPropertyChanged
    {
        private int _id;
        private int _productId;
        private DateTime _dateOfChanges;
        private string _descriptionBefore;
        private string _descriptionAfter;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public int ProductId
        {
            get { return _productId; }
            set
            {
                if (value == _productId) return;
                _productId = value;
                OnPropertyChanged();
            }
        }
        public DateTime DateOfChanges
        {
            get { return _dateOfChanges; }
            set
            {
                if (value.Equals(_dateOfChanges)) return;
                _dateOfChanges = value;
                OnPropertyChanged();
            }
        }
        public string DescriptionBefore
        {
            get { return _descriptionBefore; }
            set
            {
                if (value == _descriptionBefore) return;
                _descriptionBefore = value;
                OnPropertyChanged();
            }
        }
        public string DescriptionAfter
        {
            get { return _descriptionAfter; }
            set
            {
                if (value == _descriptionAfter) return;
                _descriptionAfter = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
