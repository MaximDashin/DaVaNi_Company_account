﻿using System;
using System.Linq;
using AutoMapper;
using CompanyAccount.Model;
using CompanyAccount.Model.Persons.Customer;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class AddEditCustomerContactsService : BaseService
    {
        private readonly IConfigurationProvider _provider;

        public AddEditCustomerContactsService(IConfigurationProvider provider)
        {
            _provider = provider;
        }

        public AddEditCustomerContactsVM GetById(int id)
        {
            AddEditCustomerContactsVM cust = context.Customers.Where(e => e.Id == id && !e.Deleted)
                .ProjectToSingleOrDefault<AddEditCustomerContactsVM>(_provider);

            var telephons = context.TelephoneNumbers.Where(e => e.CustomerId == id)
                .ProjectToList<Telephone>(_provider);
            
            foreach (var item in telephons)
            {
                cust.TelephoneNumbers.Add(item);
            }
            return cust;
        }

        public void Update(AddEditCustomerContactsVM item)
        {
            var dbItem = context.Customers.SingleOrDefault(e => e.Id == item.Id);
            if (dbItem == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var convItem = App.Mapper.Map<Customer>(item);
            convItem.CopyWithChecking(dbItem,
                e => e.Name,
                e => e.Country,
                e => e.City,
                e => e.Email,
                e => e.Skype);

            foreach (var number in dbItem.TelephoneNumbers)
            {
                if (convItem.TelephoneNumbers.Contains(number))
                {
                    var curNum = convItem.TelephoneNumbers.ToList().Find(e => e.Id == number.Id);
                    number.CopyWithChecking(curNum, e => e.CustomerId, e => e.TelNumber); 
                }
                else
                    convItem.TelephoneNumbers.Add(number);
            }

            context.SaveChanges();
        }

        public AddEditCustomerContactsVM Insert(AddEditCustomerContactsVM item)
        {
            var dbItem = App.Mapper.Map<Customer>(item);
            context.Customers.Add(dbItem);
            context.SaveChanges();
            item.Id = dbItem.Id;
            return item;
        }

        public AddEditCustomerContactsVM Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var dbItem = context.Customers.Single(e => e.Id == id);
            dbItem.Deleted = true;
            context.SaveChanges();
            return item;
        }

    }
}
