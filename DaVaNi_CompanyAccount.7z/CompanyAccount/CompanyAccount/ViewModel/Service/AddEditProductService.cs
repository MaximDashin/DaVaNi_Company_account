﻿using System;
using System.Linq;
using AutoMapper;
using CompanyAccount.Model;
using CompanyAccount.Model.Product;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class AddEditProductService : BaseService
    {
        private readonly IConfigurationProvider _provider;

        public AddEditProductService(IConfigurationProvider provider)
        {
            _provider = provider;
        }

        public AddEditProductVM GetById(int id)
        {
            return
                context.Products.Where(e => e.Id == id && !e.Deleted)
                    .ProjectToSingleOrDefault<AddEditProductVM>(_provider);
         }

        public void Update(AddEditProductVM item)
        {
            var dbItem = context.Products.SingleOrDefault(e => e.Id == item.Id);
            if (dbItem == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var convItem = App.Mapper.Map<Product>(item);
            convItem.CopyWithChecking(dbItem,
                e => e.ModelName,
                e => e.M,
                e => e.L,
                e => e.XL,
                e => e.XXL, 
                e => e.Material1,
                e => e.Material2,
                e => e.Price);
            context.SaveChanges();
        }

        public AddEditProductVM Insert(AddEditProductVM item)
        {
            var dbItem = App.Mapper.Map<Product>(item);
            context.Products.Add(dbItem);
            context.SaveChanges();
            item.Id = dbItem.Id;
            return item;
        }


        public AddEditProductVM Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var dbItem = context.Products.Single(e => e.Id == id);
            dbItem.Deleted = true;
            context.SaveChanges();
            return item;
        }

    }
}
