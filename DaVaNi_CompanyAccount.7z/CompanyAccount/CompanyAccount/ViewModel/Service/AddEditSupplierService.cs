﻿using System;
using System.Linq;
using AutoMapper;
using CompanyAccount.Model.Persons.Supplier;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class AddEditSupplierService : BaseService, IDisposable
    {
        private readonly IConfigurationProvider _provider;

        public AddEditSupplierService(IConfigurationProvider provider)
        {
            _provider = provider;
        }

        public AddEditSupplierContactsVM GetById(int id)
        {
            AddEditSupplierContactsVM supp = context.Suppliers.Where(e => e.Id == id && !e.Deleted)
                    .ProjectToSingleOrDefault<AddEditSupplierContactsVM>(_provider);

            var telephons = context.TelephoneNumbers.Where(e => e.SupplierId == id)
                .ProjectToList<Telephone>(_provider);

            foreach (var item in telephons)
            {
                supp.TelephoneNumbers.Add(item);
            }
            return supp;

        }

        public void Update(AddEditSupplierContactsVM item)
        {
            var dbItem = context.Suppliers.SingleOrDefault(e => e.Id == item.Id);
            if (dbItem == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var convItem = App.Mapper.Map<Supplier>(item);
            convItem.CopyWithChecking(dbItem,
                e => e.Name,
                e => e.Country,
                e => e.City,
                e => e.Email,
                e => e.Skype);

            foreach (var number in dbItem.TelephoneNumbers)
            {
                if (convItem.TelephoneNumbers.Contains(number))
                {
                    var curNum = convItem.TelephoneNumbers.ToList().Find(e => e.Id == number.Id);
                    number.CopyWithChecking(curNum, e => e.SupplierId, e => e.TelNumber);
                }
                else
                    convItem.TelephoneNumbers.Add(number);
            }
            context.SaveChanges();
        }

        public AddEditSupplierContactsVM Insert(AddEditSupplierContactsVM item)
        {
            var dbItem = App.Mapper.Map<Supplier>(item);
            context.Suppliers.Add(dbItem);
            context.SaveChanges();
            item.Id = dbItem.Id;
            return item;
        }


        public AddEditSupplierContactsVM Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var dbItem = context.Suppliers.Single(e => e.Id == id);
            dbItem.Deleted = true;
            context.SaveChanges();
            return item;
        }

    }
}
