﻿using System;
using System.Linq;
using AutoMapper;
using CompanyAccount.Model;
using CompanyAccount.Model.Persons.Supplier;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class AddEditSupplyService : BaseService
    {
        private readonly IConfigurationProvider _provider;

        public AddEditSupplyService(IConfigurationProvider provider)
        {
            _provider = provider;
        }

        public AddEditSupplyVM GetById(int id)
        {
            return
                context.Supplies.Where(e => e.Id == id && !e.Deleted)
                    .ProjectToSingleOrDefault<AddEditSupplyVM>(_provider); 
        }

        public void Update(AddEditSupplyVM item)
        {
            var dbItem = context.Supplies.SingleOrDefault(e => e.Id == item.Id); 
            if (dbItem == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var convItem = App.Mapper.Map<Supply>(item);
            convItem.CopyWithChecking(dbItem,
                e => e.SupplierId,
                e => e.MaterialName,
                e => e.Description,
                e => e.Price);
            context.SaveChanges();
        }

        public AddEditSupplyVM Insert(AddEditSupplyVM item)
        {
            var dbItem = App.Mapper.Map<Supply>(item);
            context.Supplies.Add(dbItem);
            context.SaveChanges();
            item.Id = dbItem.Id;
            return item;
        }


        public AddEditSupplyVM Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var dbItem = context.Supplies.Single(e => e.Id == id);
            dbItem.Deleted = true;
            context.SaveChanges();
            return item;
        }

    }
}

