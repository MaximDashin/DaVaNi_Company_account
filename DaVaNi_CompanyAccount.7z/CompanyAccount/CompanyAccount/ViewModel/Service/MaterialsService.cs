﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper.QueryableExtensions;
using CompanyAccount.Model.Material;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class MaterialsService : BaseService
    {
        #region Part for add/edit window

        public IEnumerable<IParamValue> GetParamsForMaterial(int id)
        {
            var material = context.Material.SingleOrDefault(e => e.MaterialId == id);
            if (material == null)
            {
                throw new InvalidOperationException("item not found");
            }
            foreach (var materialParam in material.MaterialParams)
            {
                var value = GetParamValue(materialParam.ParamTypeId, materialParam.MatTypeId);
                value.ParametrId = materialParam.ParamType.ParamTypeId;
                value.ParametrName = materialParam.ParamType.ParamTypeProp;
                value.ParametrValue = materialParam.Value;
                yield return value;
            }
        }

        public IEnumerable<IParamValue> GetParamsForNewMaterial(MatTypeId materialTypeId)
        {
            var materialType = context.MatType.SingleOrDefault(e => e.MatTypeId == materialTypeId);
            if (materialType == null)
            {
                throw new InvalidOperationException("item not found");
            }
            foreach (var paramType in materialType.ParamType)
            {
                var paramValue = GetParamValue(paramType.ParamTypeId, materialTypeId);
                paramValue.ParametrId = paramType.ParamTypeId;
                paramValue.ParametrName = paramType.ParamTypeProp;
                yield return paramValue;
            }
        }

        public void UpdateParamValue(int materialId, IParamValue paramValue)
        {
            var material = context.Material.SingleOrDefault(e => e.MaterialId == materialId);
            var materialParamValue = material.MaterialParams.SingleOrDefault(e => e.ParamTypeId == paramValue.ParametrId);
            if (materialParamValue == null)
            {
                materialParamValue = new MaterialParams
                {
                    ParamTypeId = paramValue.ParametrId,
                    MatTypeId = material.MatTypeId,
                    Value = paramValue.ParametrValue
                };
                material.MaterialParams.Add(materialParamValue);
            }
            else
            {
                materialParamValue.Value = paramValue.ParametrValue;
            }
            context.SaveChanges();
        }

        public IList<MatName> GetMaterialNames()
        {
            var list = context.MatType.ProjectTo<MatName>(App.Mapper.ConfigurationProvider).ToList();

            return list;
        }

        public MatName GetMaterialById(int id)
        {
            var item = context.Material.SingleOrDefault(e => e.MaterialId == id);
            return App.Mapper.Map<MatName>(item);
        }

        public void AddMaterial(ICollection<IParamValue> values, MatTypeId materialTypeId)
        {
            Material material = new Material {MatTypeId = materialTypeId};
            foreach (var value in values)
            {
                material.MaterialParams.Add(new MaterialParams
                {
                    MaterialId = material.MaterialId,
                    MatTypeId = materialTypeId,
                    Value = value.ParametrValue,
                    ParamTypeId = value.ParametrId
                   
                });
            }

            context.Material.Add(material);
            context.SaveChanges();
        }

        private IParamValue GetParamValue(ParamTypeId paramTypeId, MatTypeId materialTypeId)
        {
            IParamValue value = null;
            switch (paramTypeId)
            {
                case ParamTypeId.Raw:
                    {
                        if (materialTypeId == MatTypeId.Textile)
                        {
                            value = new DropdownParamValue(new[] { "Плащевка", "Шерсть" });
                        }
                        else if ((materialTypeId == MatTypeId.Leather) && (materialTypeId == MatTypeId.Fur))
                        {
                            value = new DropdownParamValue(new[] { "Овчина", "Телятина", "Дестрой" });
                        }
                        break;
                    }
                case ParamTypeId.Type:
                    value = new RadiobuttonParamValue(new[] {"Искуственный", "Натуральный"});
                    break;
                case ParamTypeId.Supplier:
                    value = new DropdownParamValue(context.Suppliers.Select(e => e.Name).ToList());
                    break;
                default:
                    value = new TextParamValue();
                    break;
            }
            return value;
        }


        #endregion

        #region Part for table pages

        public IEnumerable<TextileTable> GetTextileMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Textile && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new TextileTable
            {
                Id = material.MaterialId,
                Number = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Number).Value,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Raw = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Raw).Value,
                Color = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Color).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<LeatherTable> GetLeatherMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Leather && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new LeatherTable
            {
                Id = material.MaterialId,
                Number = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Number).Value,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Raw = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Raw).Value,
                Type = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Type).Value,
                Color = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Color).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<FurTable> GetFurMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Fur && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new FurTable
            {
                Id = material.MaterialId,
                Number = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Number).Value,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Raw = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Raw).Value,
                Type = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Type).Value,
                Color = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Color).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<LiningTable> GetLiningMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Lining && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new LiningTable
            {
                Id = material.MaterialId,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Color = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Color).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<LatexTable> GetLatexMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Latex && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new LatexTable
            {
                Id = material.MaterialId,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Thickness = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Thickness).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<FoamRubberTable> GetFoamRubberMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.FoamRubber && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new FoamRubberTable
            {
                Id = material.MaterialId,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Thickness = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Thickness).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<SinteponTable> GetSinteponMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Sintepon && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new SinteponTable
            {
                Id = material.MaterialId,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.MaterialName).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Size = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Size).Value,
                Thickness = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Thickness).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<VisorTable> GetVisorMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Visor && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new VisorTable
            {
                Id = material.MaterialId,
                ModelForVisor = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.ModelForVisor).Value,
                VisorLenght = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.VisorLenght).Value,
                Quality = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Thickness = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Thickness).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }

        public IEnumerable<ThreadTable> GetThreadMaterials()
        {
            var materialList = context.Material.Where(e => e.MatTypeId == MatTypeId.Thread && !e.Deleted && !e.Deleted);
            foreach (var material in materialList)
            {
                material.MaterialParams = new List<MaterialParams>(context.MaterialParams.Where(e => e.MaterialId == material.MaterialId));
            }

            return materialList.Select(material => new ThreadTable
            {
                Id = material.MaterialId,
                Number = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.ModelForVisor).Value,
                MaterialName = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.VisorLenght).Value,
                Color = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quality).Value,
                Quantity = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Quantity).Value,
                Price = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Price).Value,
                Supplier = material.MaterialParams.Single(e => e.ParamTypeId == ParamTypeId.Supplier).Value
            });
        }


        public void Delete(int index)
        {
            var material = context.Material.Single(e => e.MaterialId == index);
            material.Deleted = true;

            context.SaveChanges();

            //var values = Enum.GetValues(typeof (ParamTypeId)).Cast<ParamTypeId>().ToArray();
        }

        #endregion

    }

    public enum ParamTypeId
    {
        Raw = 1,
        Type,
        Number,
        MaterialName,
        ModelForVisor,
        VisorLenght,
        Color,
        Quality,
        Quantity,
        Size,
        Thickness,
        Price,
        Supplier
    }

    public enum MatTypeId
    {
        Textile = 1,
        Leather,
        Fur,
        Lining,
        Latex,
        FoamRubber,
        Sintepon,
        Visor,
        Thread
    }
}
