﻿using System;
using System.Linq;
using AutoMapper;
using CompanyAccount.Model;
using CompanyAccount.Model.Persons.Employee;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel.Service
{
    public class AddEditEmployeeService : BaseService
    {
        private readonly IConfigurationProvider _provider;

        public AddEditEmployeeService(IConfigurationProvider provider)
        {
            _provider = provider;
        }

        public AddEditEmployeeVM GetById(int id)
        {
            AddEditEmployeeVM emp = context.Employees.Where(e => e.Id == id && !e.Deleted)
                .ProjectToSingleOrDefault<AddEditEmployeeVM>(_provider);

            var telephons = context.TelephoneNumbers.Where(e => e.EmployeeId == id)
                .ProjectToList<Telephone>(_provider);

            foreach (var item in telephons)
            {
                emp.TelephoneNumbers.Add(item);
            }

            var documents = context.Photos.Where(e => e.EmployeeId == id)
                .ProjectToList<AddEditEmployeeVM.Document>(_provider);

            foreach (var document in documents)
            {
                emp.Documents.Add(document);
            }
            return emp;
        }

        public void Update(AddEditEmployeeVM item)
        {
            var dbItem = context.Employees.SingleOrDefault(e => e.Id == item.Id);
            if (dbItem == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var convItem = App.Mapper.Map<Employee>(item);
            convItem.CopyWithChecking(dbItem,
                e => e.Name,
                e => e.EmploymentDate,
                e => e.Post,
                e => e.Salary);

            foreach (var number in dbItem.TelephoneNumbers)
            {
                if (convItem.TelephoneNumbers.Contains(number))
                {
                    var curNum = convItem.TelephoneNumbers.ToList().Find(e => e.Id == number.Id);
                    number.CopyWithChecking(curNum, e => e.EmployeeId, e => e.TelNumber);
                }
                else
                    convItem.TelephoneNumbers.Add(number);
            }

            foreach (var document in dbItem.Documents)
            {
                if (convItem.Documents.Contains(document))
                {
                    var curDoc = convItem.Documents.ToList().Find(e => e.Id == document.Id);
                    document.CopyWithChecking(curDoc, e => e.EmployeeId, e => e.Name, e => e.DataBytes);
                }
                else
                    convItem.Documents.Add(document);
            }
            context.SaveChanges();
        }

        public AddEditEmployeeVM Insert(AddEditEmployeeVM item)
        {
            var dbItem = App.Mapper.Map<Employee>(item);
            context.Employees.Add(dbItem);
            context.SaveChanges();
            item.Id = dbItem.Id;
            return item;
        }


        public AddEditEmployeeVM Delete(int id)
        {
            var item = GetById(id);
            if (item == null)
            {
                throw new InvalidOperationException("Item not found");
            }
            var dbItem = context.Employees.Single(e => e.Id == id);
            dbItem.Deleted = true;
            context.SaveChanges();
            return item;
        }

    }
}
