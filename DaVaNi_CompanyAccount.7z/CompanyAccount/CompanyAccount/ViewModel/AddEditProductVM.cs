﻿using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditProductVM
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public int M { get; set; }
        public int L { get; set; }
        public int XL { get; set; }
        public int XXL { get; set; }
        public string Material1 { get; set; }
        public string Material2 { get; set; }
        public float Price { get; set; }

        private readonly AddEditProductService _service;

        public AddEditProductVM() : this(0) { }

        public AddEditProductVM(int id)
        {
            _service = new AddEditProductService(App.Mapper.ConfigurationProvider);
            if (id != 0)
            {
                GetProductById(id);
            }
        }

        public void AddProduct()
        {
            var item = GetItem();

            _service.Insert(item);
        }

        public void EditProduct()
        {
            var item = GetItem();

            _service.Update(item);
        }

        public void Confirm(int id)
        {
            if (id == 0)
                AddProduct();
            else
                EditProduct();
        }

        public void GetProductById(int id)
        {
            var product = _service.GetById(id);

            Id = product.Id;
            ModelName = product.ModelName;
            M = product.M;
            L = product.L;
            XL = product.XL;
            XXL = product.XXL;
            Material1 = product.Material1;
            Material2 = product.Material2;
            Price = product.Price;
        }

        private AddEditProductVM GetItem()
        {
            AddEditProductVM item = new AddEditProductVM
            {
                Id = Id,
                ModelName = ModelName,
                M = M,
                L = L,
                XL = XL,
                XXL = XXL,
                Material1 = Material1,
                Material2 = Material2,
                Price = Price
            };
            return item;
        }

    }
}
