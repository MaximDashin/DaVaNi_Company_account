﻿using CompanyAccount.ViewModel.Service;

namespace CompanyAccount.ViewModel
{
    public class AddEditSupplyVM 
    {
        public int Id { get; set; }
        public int SupplierId { get; set; }
        public string MaterialName { get; set; }
        public string Description { get; set; }
        public float Price { get; set; }

        private readonly AddEditSupplyService _service;

        public AddEditSupplyVM() : this(0) { }

        public AddEditSupplyVM(int id)
        {
            _service = new AddEditSupplyService(App.Mapper.ConfigurationProvider);
            if (id != 0)
            {
                GetSupplyById(id);
            }
        }
        public void AddSupply(int supplierId)
        {
            var item = GetItem();
            item.SupplierId = supplierId;

            _service.Insert(item);
        }

        public void EditSupply()
        {
            var item = GetItem();

            _service.Update(item);
        }

        public void GetSupplyById(int id)
        {
            var supply = _service.GetById(id);

            Id = supply.Id;
            SupplierId = supply.SupplierId;
            MaterialName = supply.MaterialName;
            Description = supply.Description;
            Price = supply.Price;
        }

        public void Confirm(int supplyId, int supplierId)
        {
            if (supplyId == 0)
                AddSupply(supplierId);
            else
                EditSupply();
        }

        private AddEditSupplyVM GetItem()
        {
            AddEditSupplyVM item = new AddEditSupplyVM
            {
                Id = Id,
                SupplierId = SupplierId !=0 ? SupplierId : 1,
                MaterialName = MaterialName,
                Description = Description,
                Price = Price
            };
            return item;
        }
    }
}
