﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using AutoMapper.QueryableExtensions;
using CompanyAccount.Annotations;
using CompanyAccount.Model.Persons.Customer;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class OrderDetailsTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<OrderDetailsTable> Items { get; set; }
        public OrderDetailsTable SelectedItem { get; set; }

        public OrderDetailsTableVM() : this(0) { }
        public OrderDetailsTableVM(int orderId=0)
        {
            if (orderId == 0)
            {
                Items = new ObservableCollection<OrderDetailsTable>();
                    //(new List<OrderDetailsTable>()); //todo: проверить может прийдется инициализировать пустыми полями
            }
            else
            {
                Items = new ObservableCollection<OrderDetailsTable>(context.Orders.Where(e => !e.Deleted && e.Id == orderId)
                            .ProjectTo<OrderDetailsTable>(App.Mapper.ConfigurationProvider));
            }
        }

        public void Delete()
        {
            var elementToDelete = context.Orders.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        public void Save(int customerId, int orderId)
        {
            if (orderId == 0)
            {
                foreach (var item in Items)
                {
                    context.Orders.Add(new Order
                    {
                        Id = item.Id,
                        CustomerId = customerId,
                        OrderNumber = item.OrderNumber,
                        Model = item.Model,
                        Quantity = item.Quantity,
                        PriceForOne = item.PriceForOne,
                        PriceForAll = item.PriceForAll,
                        OrderDate = item.OrderDate
                    });
                }
            }
            else
            {
                foreach (var item in Items)
                {
                    var order = context.Orders.Single(e => e.Id == item.Id);

                    var convItem = App.Mapper.Map<Order>(item); // todo: ASK

                    convItem.CopyWithChecking(order,
                        e => e.OrderNumber,
                        e => e.Model,
                        e => e.Quantity,
                        e => e.PriceForOne,
                        e => e.PriceForAll,
                        e => e.OrderDate);

                    //if (order.OrderNumber != item.OrderNumber)
                    //    order.OrderNumber = item.OrderNumber;
                    //if (order.Model != item.Model)
                    //    order.Model = item.Model;
                    //if (order.Quantity != item.Quantity)
                    //    order.Quantity = item.Quantity;
                    //if (order.PriceForOne != item.PriceForOne)
                    //    order.PriceForOne = item.PriceForOne;
                    //if (order.PriceForAll != item.PriceForAll)
                    //    order.PriceForAll = item.PriceForAll;
                    //if (order.OrderDate != item.OrderDate)
                    //    order.OrderDate = item.OrderDate;

                    context.SaveChanges();
                }
            }

            context.SaveChanges();
        }

        public string GetOrderNumber(int id)
        {
            return context.Orders.Single(e => e.Id == id).OrderNumber;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class OrderDetailsTable : INotifyPropertyChanged
    {
        private int _id;
        private int _customerId;
        private string _orderNumber;
        private string _model;
        private int _quantity;
        private float _priceForOne;
        private DateTime _orderDate;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public int CustomerId
        {
            get { return _customerId; }
            set
            {
                if (value == _customerId) return;
                _customerId = value;
                OnPropertyChanged();
            }
        }
        public string OrderNumber
        {
            get { return _orderNumber; }
            set
            {
                if (value == _orderNumber) return;
                _orderNumber = value;
                OnPropertyChanged();
            }
        }
        public string Model
        {
            get { return _model; }
            set
            {
                if (value == _model) return;
                _model = value;
                OnPropertyChanged();
            }
        }
        public int Quantity
        {
            get { return _quantity; }
            set
            {
                if (value == _quantity) return;
                _quantity = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(PriceForAll));
            }
        }
        public float PriceForOne
        {
            get { return _priceForOne; }
            set
            {
                if (value.Equals(_priceForOne)) return;
                _priceForOne = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(PriceForAll));
            }
        }
        public float PriceForAll => Quantity*PriceForOne;
        public DateTime OrderDate
        {
            get { return _orderDate; }
            set
            {
                if (value.Equals(_orderDate)) return;
                _orderDate = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
