﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CompanyAccount.Annotations;
using System.Linq;
using AutoMapper.QueryableExtensions;
using CompanyAccount.ViewModel.Plagin;

namespace CompanyAccount.ViewModel
{
    public class EmployeeTableVM : BaseService, INotifyPropertyChanged
    {
        public ObservableCollection<EmployeeTable> Items { get; set; }
        public EmployeeTable SelectedItem { get; set; }
        
        public EmployeeTableVM()
        {
            Items = new ObservableCollection<EmployeeTable>(context.Employees.Where(e => !e.Deleted)
                                                            .ProjectTo<EmployeeTable>(App.Mapper.ConfigurationProvider));
        }

        public void Delete()
        {
            var elementToDelete = context.Employees.SingleOrDefault(e => e.Id == SelectedItem.Id);
            if (elementToDelete != null)
                elementToDelete.Deleted = true;

            context.SaveChanges();
        }

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }

    public class EmployeeTable : INotifyPropertyChanged
    {
        private int _id;
        private string _name;

        public int Id
        {
            get { return _id; }
            set
            {
                if (value == _id) return;
                _id = value;
                OnPropertyChanged();
            }
        }
        public string Name
        {
            get { return _name; }
            set
            {
                if (value == _name) return;
                _name = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
