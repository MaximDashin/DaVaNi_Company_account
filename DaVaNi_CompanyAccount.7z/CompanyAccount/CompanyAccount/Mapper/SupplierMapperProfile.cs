﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using CompanyAccount.Model.Persons;
using CompanyAccount.Model.Persons.Supplier;
using CompanyAccount.ViewModel;
using Supplier = CompanyAccount.Model.Persons.Supplier.Supplier;

namespace CompanyAccount.Mapper
{
    class SupplierMapperProfile : Profile
    {
        protected override void Configure()
        {
                //telephone
                CreateMap<TelephoneNumber, Telephone>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.PersonId, r => r.MapFrom(e => e.SupplierId))
                    .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));

                CreateMap<Telephone, TelephoneNumber>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.SupplierId, r => r.MapFrom(e => e.PersonId))
                    .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));


                // short supplier information
                CreateMap<Supplier, SupplierTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Name, r => r.MapFrom(e => e.Name));

                // full supplier information
                CreateMap<Supplier, AddEditSupplierContactsVM>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                    .ForMember(e => e.Country, r => r.MapFrom(e => e.Country))
                    .ForMember(e => e.City, r => r.MapFrom(e => e.City))
                    .ForMember(e => e.Email, r => r.MapFrom(e => e.Email))
                    .ForMember(e => e.Skype, r => r.MapFrom(e => e.Skype));

                CreateMap<AddEditSupplierContactsVM, Supplier>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                    .ForMember(e => e.Country, r => r.MapFrom(e => e.Country))
                    .ForMember(e => e.City, r => r.MapFrom(e => e.City))
                    .ForMember(e => e.Email, r => r.MapFrom(e => e.Email))
                    .ForMember(e => e.Skype, r => r.MapFrom(e => e.Skype));

                // supply information
                CreateMap<Supply, SupplyInformation>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.SupplierId, r => r.MapFrom(e => e.SupplierId))
                    .ForMember(e => e.MaterialName, r => r.MapFrom(e => e.MaterialName))
                    .ForMember(e => e.Description, r => r.MapFrom(e => e.Description))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<SupplyInformation, Supply>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.SupplierId, r => r.MapFrom(e => e.SupplierId))
                    .ForMember(e => e.MaterialName, r => r.MapFrom(e => e.MaterialName))
                    .ForMember(e => e.Description, r => r.MapFrom(e => e.Description))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // add edit supply
                CreateMap<Supply, AddEditSupplyVM>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.SupplierId, r => r.MapFrom(e => e.SupplierId))
                    .ForMember(e => e.MaterialName, r => r.MapFrom(e => e.MaterialName))
                    .ForMember(e => e.Description, r => r.MapFrom(e => e.Description))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<AddEditSupplyVM, Supply>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.SupplierId, r => r.MapFrom(e => e.SupplierId))
                    .ForMember(e => e.MaterialName, r => r.MapFrom(e => e.MaterialName))
                    .ForMember(e => e.Description, r => r.MapFrom(e => e.Description))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

            
        }
    }
}
