﻿using AutoMapper;
using CompanyAccount.Model.Product;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Mapper
{
    class ProductMapperProfile : Profile
    {
        protected override void Configure()
        {
                // All
                CreateMap<Product, AllProductTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<AllProductTable, Product>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Type, r => r.MapFrom(e => e.Type))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // Cow
                CreateMap<Product, CowProductTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<CowProductTable, Product>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Type, r => r.MapFrom(e => e.Type))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // Destroy
                CreateMap<Product, DestroyProductTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<DestroyProductTable, Product>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Type, r => r.MapFrom(e => e.Type))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // Sheep
                CreateMap<Product, SheepProductTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<SheepProductTable, Product>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Type, r => r.MapFrom(e => e.Type))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // Textile
                CreateMap<Product, TextileProductTable>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                CreateMap<TextileProductTable, Product>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.Type, r => r.MapFrom(e => e.Type))
                    .ForMember(e => e.ModelName, r => r.MapFrom(e => e.ModelName))
                    .ForMember(e => e.M, r => r.MapFrom(e => e.M))
                    .ForMember(e => e.L, r => r.MapFrom(e => e.L))
                    .ForMember(e => e.XL, r => r.MapFrom(e => e.XL))
                    .ForMember(e => e.XXL, r => r.MapFrom(e => e.XXL))
                    .ForMember(e => e.Material1, r => r.MapFrom(e => e.Material1))
                    .ForMember(e => e.Material2, r => r.MapFrom(e => e.Material2))
                    .ForMember(e => e.Price, r => r.MapFrom(e => e.Price));

                // information changes
                CreateMap<InformationChanges, ProductsInformationChanges>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ProductId, r => r.MapFrom(e => e.ProductId))
                    .ForMember(e => e.DateOfChanges, r => r.MapFrom(e => e.DateOfChanges))
                    .ForMember(e => e.DescriptionBefore, r => r.MapFrom(e => e.DescriptionBefore))
                    .ForMember(e => e.DescriptionAfter, r => r.MapFrom(e => e.DescriptionAfter));

                CreateMap<ProductsInformationChanges, InformationChanges>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.ProductId, r => r.MapFrom(e => e.ProductId))
                    .ForMember(e => e.DateOfChanges, r => r.MapFrom(e => e.DateOfChanges))
                    .ForMember(e => e.DescriptionBefore, r => r.MapFrom(e => e.DescriptionBefore))
                    .ForMember(e => e.DescriptionAfter, r => r.MapFrom(e => e.DescriptionAfter));

            

        }
    }
}
