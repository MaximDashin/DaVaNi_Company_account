﻿using AutoMapper;
using CompanyAccount.Model.Persons;
using CompanyAccount.Model.Persons.Customer;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Mapper
{
    class CustomerMapperProfile : Profile
    {
        protected override void Configure()
        {
                //telephone 
            CreateMap<TelephoneNumber, Telephone>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.PersonId, r => r.MapFrom(e => e.CustomerId))
                .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));
                
            CreateMap<Telephone, TelephoneNumber>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.CustomerId, r => r.MapFrom(e => e.PersonId))
                .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));



            // short customer information
            CreateMap<Customer, CustomerTable>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name));

            // full customer information
            CreateMap<Customer, AddEditCustomerContactsVM>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.Country, r => r.MapFrom(e => e.Country))
                .ForMember(e => e.City, r => r.MapFrom(e => e.City))
                .ForMember(e => e.Email, r => r.MapFrom(e => e.Email))
                .ForMember(e => e.Skype, r => r.MapFrom(e => e.Skype));

            CreateMap<AddEditCustomerContactsVM, Customer>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.Country, r => r.MapFrom(e => e.Country))
                .ForMember(e => e.City, r => r.MapFrom(e => e.City))
                .ForMember(e => e.Email, r => r.MapFrom(e => e.Email))
                .ForMember(e => e.Skype, r => r.MapFrom(e => e.Skype));

            // short order information
            CreateMap<Order, OrdersTable>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.CustomerId, r => r.MapFrom(e => e.CustomerId))
                .ForMember(e => e.OrderNumber, r => r.MapFrom(e => e.OrderNumber))
                .ForMember(e => e.Date, r => r.MapFrom(e => e.OrderDate));

            // full order information
            CreateMap<Order, OrderDetailsTable>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.CustomerId, r => r.MapFrom(e => e.CustomerId))
                .ForMember(e => e.OrderNumber, r => r.MapFrom(e => e.OrderNumber))
                .ForMember(e => e.Model, r => r.MapFrom(e => e.Model))
                .ForMember(e => e.Quantity, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.PriceForOne, r => r.MapFrom(e => e.PriceForOne))
                .ForMember(e => e.OrderDate, r => r.MapFrom(e => e.OrderDate));

            CreateMap<OrderDetailsTable, Order>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.CustomerId, r => r.MapFrom(e => e.CustomerId))
                .ForMember(e => e.OrderNumber, r => r.MapFrom(e => e.OrderNumber))
                .ForMember(e => e.Model, r => r.MapFrom(e => e.Model))
                .ForMember(e => e.Quantity, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.PriceForOne, r => r.MapFrom(e => e.PriceForOne))
                .ForMember(e => e.PriceForAll, r => r.MapFrom(e => e.PriceForAll))
                .ForMember(e => e.OrderDate, r => r.MapFrom(e => e.OrderDate));
        }
    }
}
