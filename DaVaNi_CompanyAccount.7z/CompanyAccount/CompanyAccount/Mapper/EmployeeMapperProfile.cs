﻿using AutoMapper;
using CompanyAccount.Model.Persons;
using CompanyAccount.Model.Persons.Employee;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Mapper
{
    class EmployeeMapperProfile : Profile
    {
        protected override void Configure()
        {
                //telephone
            CreateMap<TelephoneNumber, Telephone>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.PersonId, r => r.MapFrom(e => e.EmployeeId))
                .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));

            CreateMap<Telephone, TelephoneNumber>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.EmployeeId, r => r.MapFrom(e => e.PersonId))
                .ForMember(e => e.TelNumber, r => r.MapFrom(e => e.TelNumber));

            //Documents
            CreateMap<Photo, AddEditEmployeeVM.Document>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.EmployeeId, r => r.MapFrom(e => e.EmployeeId))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.Data, r => r.MapFrom(e => e.DataBytes));

            CreateMap<AddEditEmployeeVM.Document, Photo>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.EmployeeId, r => r.MapFrom(e => e.EmployeeId))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.DataBytes, r => r.MapFrom(e => e.Data));

//*************************************************************************************************

            // short employee information
            CreateMap<Employee, EmployeeTable>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name));

            CreateMap<EmployeeTable, Employee>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name));

            // full employee information read only
            CreateMap<Employee, EmployeeInformationVM>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.EmploymentDate, r => r.MapFrom(e => e.EmploymentDate))
                .ForMember(e => e.Post, r => r.MapFrom(e => e.Post))
                .ForMember(e => e.Salary, r => r.MapFrom(e => e.Salary));

            // add edit information
            CreateMap<Employee, AddEditEmployeeVM>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.EmploymentDate, r => r.MapFrom(e => e.EmploymentDate))
                .ForMember(e => e.Post, r => r.MapFrom(e => e.Post))
                .ForMember(e => e.Salary, r => r.MapFrom(e => e.Salary));

            CreateMap<AddEditEmployeeVM, Employee>()
                .ForMember(e => e.Id, r => r.MapFrom(e => e.Id))
                .ForMember(e => e.Name, r => r.MapFrom(e => e.Name))
                .ForMember(e => e.EmploymentDate, r => r.MapFrom(e => e.EmploymentDate))
                .ForMember(e => e.Post, r => r.MapFrom(e => e.Post))
                .ForMember(e => e.Salary, r => r.MapFrom(e => e.Salary));


            
        }
    }
}
