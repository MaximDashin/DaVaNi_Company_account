﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using CompanyAccount.Model.Material;
using CompanyAccount.Model.Persons;
using CompanyAccount.ViewModel;

namespace CompanyAccount.Mapper
{
    class MaterialMapperProfile : Profile
    {
        protected override void Configure()
        {
            CreateMap<MatType, MatName>()
                    .ForMember(e => e.Id, r => r.MapFrom(e => e.MatTypeId))
                    .ForMember(e => e.Name, r => r.MapFrom(e => e.MatTypeName));

            CreateMap<MatName, MatType>()
                    .ForMember(e => e.MatTypeId, r => r.MapFrom(e => e.Id))
                    .ForMember(e => e.MatTypeName, r => r.MapFrom(e => e.Name));
        }
    }
}
